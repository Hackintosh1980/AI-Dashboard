# csv_viewer_screen.py – FINAL, HeaderBar-kompatibel

import os
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button

from dashboard_gui.ui.common.header_online import HeaderBar
from dashboard_gui.ui.csv_viewer_content.csv_viewer_filebrowser import CSVViewerFileBrowser
from dashboard_gui.ui.csv_viewer_content.csv_viewer_table import CSVTableView
from dashboard_gui.ui.csv_viewer_content.csv_viewer_graphs import CSVGraphView
from dashboard_gui.ui.scaling_utils import dp_scaled, sp_scaled
from dashboard_gui.global_state_manager import GLOBAL_STATE


class CSVViewerScreen(Screen):

    def __init__(self, **kw):
        super().__init__(**kw)
        GLOBAL_STATE.attach_csv_viewer(self)

        self.current_csv = None
        self.active_tab = "Table"

        # ------------------------------------------------------------
        # ROOT
        # ------------------------------------------------------------
        root = BoxLayout(orientation="vertical")
        self.add_widget(root)

        # ------------------------------------------------------------
        # HEADERBar (dein echtes Header-System)
        # ------------------------------------------------------------
        self.header = HeaderBar(
            goto_setup=lambda: setattr(self.manager, "current", "setup"),
            goto_debug=lambda: setattr(self.manager, "current", "debug"),
            goto_device_picker=None,
        )
        self.header.lbl_title.text = "CSV Viewer"
        self.header.enable_back("dashboard")
        root.add_widget(self.header)

        # ------------------------------------------------------------
        # TAB-ROW
        # ------------------------------------------------------------
        tab_row = BoxLayout(
            orientation="horizontal",
            size_hint_y=None,
            height=dp_scaled(40),
            spacing=dp_scaled(6),
            padding=[dp_scaled(6), dp_scaled(4)],
        )

        self.btn_tab_table = Button(
            text="Tabelle",
            background_normal="",
            background_down="",
            background_color=(0.20, 0.30, 0.70, 1),
            color=(0.95, 0.95, 0.98, 1),
            font_size=sp_scaled(14),
        )
        self.btn_tab_table.bind(on_release=lambda *_: self._switch_tab("Table"))

        self.btn_tab_graph = Button(
            text="Graph",
            background_normal="",
            background_down="",
            background_color=(0.12, 0.12, 0.18, 1),
            color=(0.95, 0.95, 0.98, 1),
            font_size=sp_scaled(14),
        )
        self.btn_tab_graph.bind(on_release=lambda *_: self._switch_tab("Graph"))

        tab_row.add_widget(self.btn_tab_table)
        tab_row.add_widget(self.btn_tab_graph)
        root.add_widget(tab_row)

        # ------------------------------------------------------------
        # ACTION BUTTON ROW  (***NEU***)
        # ------------------------------------------------------------
        action_row = BoxLayout(
            orientation="horizontal",
            size_hint_y=None,
            height=dp_scaled(44),
            spacing=dp_scaled(8),
            padding=[dp_scaled(6), dp_scaled(4)]
        )

        self.btn_open_file = Button(
            text="Datei öffnen",
            background_normal="",
            background_down="",
            background_color=(0.20, 0.25, 0.35, 1),
            color=(0.95, 0.95, 0.98, 1),
            font_size=sp_scaled(16),
        )
        self.btn_open_file.bind(on_release=lambda *_: self._open_file())
        action_row.add_widget(self.btn_open_file)

        root.add_widget(action_row)

        # ------------------------------------------------------------
        # CONTENT AREA
        # ------------------------------------------------------------
        self.area = BoxLayout(orientation="vertical")
        root.add_widget(self.area)
        
        # Deine Module
        self.table = CSVTableView()
        self.graph = CSVGraphView()

        # Standardansicht
        self._switch_tab("Table")

        # ------------------------------------------------------------
        # FILE OPEN TRIGGER über Menü (BONUS)
        # ------------------------------------------------------------
        # Wir hängen den File-Open an den Menü-Button des Headers.
        # Kein override – nur Zusatz.
        # Der HeaderBar hat einen Menü-Button -> sein WindowPicker
        # ruft goto_csv für Screens auf. Hier erweitern wir NICHTS.

    # ================================================================
    #  BACK
    # ================================================================
    def _back(self, *_):
        self.manager.current = "dashboard"

    # ================================================================
    #  FILEBROWSER
    # ================================================================
    def _open_file(self, *_):
        fb = CSVViewerFileBrowser(on_select=self._file_selected)
        self.add_widget(fb)

    def _file_selected(self, path):
        self.current_csv = path
        if self.active_tab == "Table":
            self.table.set_csv_path(path)
        elif self.active_tab == "Graph":
            self.graph.set_csv_path(path)

    # ================================================================
    #  TAB SWITCH
    # ================================================================
    def _switch_tab(self, name):

        self.active_tab = name
        self.area.clear_widgets()

        # Farbe aktualisieren
        if name == "Table":
            self.btn_tab_table.background_color = (0.20, 0.30, 0.70, 1)
            self.btn_tab_graph.background_color = (0.12, 0.12, 0.18, 1)

            self.area.add_widget(self.table)
            if self.current_csv:
                self.table.set_csv_path(self.current_csv)

        elif name == "Graph":
            self.btn_tab_graph.background_color = (0.20, 0.30, 0.70, 1)
            self.btn_tab_table.background_color = (0.12, 0.12, 0.18, 1)

            self.area.add_widget(self.graph)
            if self.current_csv:
                self.graph.set_csv_path(self.current_csv)
    def update_from_global(self, d):
        self.header.update_from_global(d)                
