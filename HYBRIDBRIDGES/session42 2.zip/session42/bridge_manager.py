#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
bridge_manager.py – Plattformübergreifende Bridge-Steuerung 🌿
Startet und stoppt automatisch die passende BLE-Bridge (Android / Desktop)
© 2025 Dominik Rosenthal (Hackintosh1980)
"""

from kivy.utils import platform


# ------------------------------------------------------------
# 🧩 Bridge-Basisinterface
# ------------------------------------------------------------
class BridgeInterface:
    def start(self): ...
    def stop(self): ...
    def get_status(self):
        return {"running": False, "bt_enabled": False, "source": "unknown"}


# ------------------------------------------------------------
# 🤖 Android-Implementierung (BleBridgePersistent)
# ------------------------------------------------------------
class BleBridgeAndroid(BridgeInterface):
    def __init__(self):
        self.running = False
        self.bt_enabled = False

    def start(self):
        try:
            from jnius import autoclass
            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            ctx = PythonActivity.mActivity
            BleBridgePersistent = autoclass("org.hackintosh1980.blebridge.BleBridgePersistent")
            ret = BleBridgePersistent.start(ctx, "ble_dump.json")
            print("[BridgeAndroid] start →", ret)
            self.running = True
            self.bt_enabled = True
        except Exception as e:
            print("[BridgeAndroid] error:", e)
            self.bt_enabled = False

    def stop(self):
        try:
            from jnius import autoclass
            autoclass("org.hackintosh1980.blebridge.BleBridgePersistent").stop()
            self.running = False
        except Exception:
            pass

    def get_status(self):
        return {"running": self.running, "bt_enabled": self.bt_enabled, "source": "android"}


# ------------------------------------------------------------
# 🖥️ Plattformwahl
# ------------------------------------------------------------
def get_bridge(prefer_mock=False) -> BridgeInterface:
    if platform == "android":
        return BleBridgeAndroid()
    return BridgeInterface()
