#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sim_decoded.py – Simulator für decoded.json
Generiert lebende TB2-Sensoren mit realistischen Werten.
© 2025 Dominik Rosenthal
"""

import os
import json
import time
import random
from datetime import datetime, timezone

# ------------------------------------------------------------
# Ausgabepfad
# ------------------------------------------------------------
BASE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.abspath(os.path.join(BASE, ".."))
DATA = os.path.join(PROJECT, "data")
OUT = os.path.join(DATA, "decoded.json")
os.makedirs(DATA, exist_ok=True)

# ------------------------------------------------------------
# Timestamp Format
# ------------------------------------------------------------
def ts():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "+0000"


# ------------------------------------------------------------
# Geräte (Matching zu deinen echten TB2)
# ------------------------------------------------------------
DEVICES = [
    ("Living-A", "AA:BB:CC:00:00:01"),
    ("Living-B", "AA:BB:CC:00:00:02"),
]

packet = 0

print("[DecodedSim] START – schreibt nach:", OUT)

# ------------------------------------------------------------
# Main Loop
# ------------------------------------------------------------
while True:

    packet = (packet + 1) % 255
    arr = []

    for name, dev_id in DEVICES:

        # Basiswerte
        t_i = 20.0 + random.uniform(-0.6, 0.6)
        h_i = 55.0 + random.uniform(-2.0, 2.0)

        t_e = t_i - 0.5 + random.uniform(-0.4, 0.4)
        h_e = h_i - 3 + random.uniform(-3, 3)

        # VPD (simuliert)
        vpd_i = round(random.uniform(0.9, 1.3), 3)
        vpd_e = round(vpd_i + random.uniform(-0.05, 0.05), 3)

        obj = {
            "timestamp": ts(),
            "device_id": dev_id,
            "name": name,
            "rssi": random.randint(-70, -45),
            "packet_counter": packet,

            "sensor": {
                "vendor": "ThermoBeacon",
                "model": "TB2",
                "type": "temperature_humidity"
            },

            "internal": {
                "temperature": {"value": round(t_i, 4), "unit": "C"},
                "humidity":    {"value": round(h_i, 4), "unit": "%"}
            },

            "external": {
                "present": True,
                "temperature": {"value": round(t_e, 4), "unit": "C"},
                "humidity":    {"value": round(h_e, 4), "unit": "%"}
            },

            "vpd_internal": {"value": vpd_i, "unit": "kPa"},
            "vpd_external": {"value": vpd_e, "unit": "kPa"},

            "alive": True,
            "status": "active",
            "last_seen": 0.0,

            # Dummy RAW (braucht das UI NICHT)
            "raw": "1900AABBCCDDEEFF020045015A033B01420367",

            # Bridge-Flags
            "bridge_alive": True,
            "bridge_status": "OK",
            "bridge_last_seen": 0.0,

            "health": {
                "uptime": {"value": random.uniform(1.0, 5.0), "unit": "s"},
                "battery": {"value": None, "unit": "%", "voltage": None},
                "signal": {"rssi": random.randint(-70, -40), "quality": None}
            }
        }

        arr.append(obj)

    # atomar schreiben
    tmp = OUT + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(arr, f, indent=2)
    os.replace(tmp, OUT)

    time.sleep(1.2)
