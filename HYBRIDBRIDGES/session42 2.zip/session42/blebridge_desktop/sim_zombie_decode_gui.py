#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sim_decoded_gui.py – GUI für decoded-Simulator
© 2025 Dominik Rosenthal
"""

import os
import subprocess
import signal
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.clock import Clock

BASE = os.path.dirname(os.path.abspath(__file__))
SIM_PATH = os.path.join(BASE, "sim_decoded.py")


class DecodedSimGUI(BoxLayout):
    def __init__(self, **kw):
        super().__init__(orientation="vertical", spacing=15, padding=15, **kw)

        self.proc = None

        self.lbl_status = Label(text="[Stopped]", font_size="20sp", markup=True)
        self.add_widget(self.lbl_status)

        row = BoxLayout(size_hint=(1, 0.25), spacing=10)

        btn_start = Button(text="START decoded-Simulator", font_size="18sp")
        btn_start.bind(on_release=lambda *_: self.start_sim())
        row.add_widget(btn_start)

        btn_stop = Button(text="STOP", font_size="18sp")
        btn_stop.bind(on_release=lambda *_: self.stop_sim())
        row.add_widget(btn_stop)

        self.add_widget(row)

        self.lbl_info = Label(
            text=f"[code]{os.path.basename(SIM_PATH)}[/code]\n→ schreibt nach ../data/decoded.json",
            markup=True, font_size="12sp"
        )
        self.add_widget(self.lbl_info)

        Clock.schedule_interval(self._tick, 1)

    def start_sim(self):
        if self.proc:
            return
        if not os.path.exists(SIM_PATH):
            self.lbl_status.text = "[b][color=#ff3333]sim_decoded.py fehlt![/color][/b]"
            return

        self.proc = subprocess.Popen(
            ["python3", SIM_PATH],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        self.lbl_status.text = "[b][color=#33ff33]RUNNING – decoded Sim aktiv[/color][/b]"

    def stop_sim(self):
        if not self.proc:
            return
        try:
            os.kill(self.proc.pid, signal.SIGTERM)
        except:
            pass
        self.proc = None
        self.lbl_status.text = "[Stopped]"

    def _tick(self, dt):
        if self.proc and self.proc.poll() is not None:
            self.proc = None
            self.lbl_status.text = "[Stopped]"


class DecodedSimApp(App):
    def build(self):
        return DecodedSimGUI()


if __name__ == "__main__":
    DecodedSimApp().run()
