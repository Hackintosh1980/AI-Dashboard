#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
blebridge_desktop.py – macOS RAW BLE Scanner (FINAL)
SCHREIBT AUSSCHLIESSLICH NACH /data/ble_dump.json
© 2025 Dominik Rosenthal
"""

import json, time, threading, os, sys
from datetime import datetime, timezone

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.utils import get_color_from_hex

from Foundation import NSObject, NSRunLoop, NSDate
import CoreBluetooth as CB

# Fester Pfad: <Projektroot>/data/ble_dump.json
# Projekt-Root = eine Ebene über blebridge_desktop/
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(BASE_DIR)
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
OUT_FILE = os.path.join(DATA_DIR, "ble_dump.json")
WRITE_INTERVAL = 1.5


def ts_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "+0000"


class Store:
    def __init__(self):
        self.lock = threading.Lock()
        self.last = {}

    def update(self, ident, name, rssi, msd):
        raw = msd.hex().upper() if msd else ""
        entry = dict(
            timestamp=ts_iso(),
            name=name,
            address=ident,
            rssi=int(rssi),
            raw=raw,
            note="raw",
        )
        with self.lock:
            self.last[ident] = entry

    def snapshot(self):
        with self.lock:
            arr = list(self.last.values())
            arr.sort(key=lambda x: x["address"])
            return arr


class CentralDelegate(NSObject):
    def initWithStore_(self, store):
        self = self.init()
        self.store = store
        return self

    def centralManagerDidUpdateState_(self, manager):
        if manager.state() == CB.CBManagerStatePoweredOn:
            manager.scanForPeripheralsWithServices_options_(
                None, {"kCBScanOptionAllowDuplicatesKey": True}
            )
        else:
            print("Bluetooth state:", manager.state())

    def centralManager_didDiscoverPeripheral_advertisementData_RSSI_(self, m, p, adv, rssi):
        try:
            name = adv.get(CB.CBAdvertisementDataLocalNameKey) or p.name() or "(unknown)"
            msd = adv.get(CB.CBAdvertisementDataManufacturerDataKey)
            ident = str(p.identifier())
            self.store.update(ident, name, rssi, bytes(msd) if msd else None)
        except Exception as e:
            print("discover err:", e, file=sys.stderr)


class WriterThread(threading.Thread):
    def __init__(self, store):
        super().__init__(daemon=True)
        self.store = store
        self.run_flag = True
        os.makedirs(os.path.dirname(OUT_FILE), exist_ok=True)

    def run(self):
        while self.run_flag:
            try:
                data = self.store.snapshot()
                tmp = OUT_FILE + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                os.replace(tmp, OUT_FILE)
            except Exception as e:
                print("write err:", e)
            time.sleep(WRITE_INTERVAL)

    def stop(self):
        self.run_flag = False


class GUI(BoxLayout):
    def __init__(self, **kw):
        super().__init__(orientation="vertical", **kw)

        self.store = Store()
        self.delegate = None
        self.central = None
        self.scanning = False
        self.writer = None

        self.status = Label(text="Bereit", size_hint_y=None, height=40)
        self.add_widget(self.status)

        row = BoxLayout(size_hint_y=None, height=50)
        self.btn_start = Button(text="Start", on_release=self.start_all)
        self.btn_stop = Button(text="Stop", on_release=self.stop_all, disabled=True)
        row.add_widget(self.btn_start)
        row.add_widget(self.btn_stop)
        self.add_widget(row)

        self.path_lbl = Label(text=f"Dump: {OUT_FILE}", font_size="12sp")
        self.add_widget(self.path_lbl)

    def log(self, msg):
        self.status.text = msg

    def start_all(self, *args):
        self.scanning = True
        self.btn_start.text = "Neu starten"
        self.btn_stop.disabled = False
        self.log("Starte Scan…")

        threading.Thread(target=self._scan_thread, daemon=True).start()

        self.writer = WriterThread(self.store)
        self.writer.start()
        self.log("Scan läuft…")

    def stop_all(self, *args):
        self.scanning = False
        self.btn_stop.disabled = True
        self.log("Stoppe…")

        try:
            if self.central:
                self.central.stopScan()
        except Exception:
            pass

        if self.writer:
            self.writer.stop()

        self.log("Gestoppt.")

    def _scan_thread(self):
        try:
            self.delegate = CentralDelegate.alloc().initWithStore_(self.store)
            self.central = CB.CBCentralManager.alloc().initWithDelegate_queue_options_(
                self.delegate, None, None
            )
            rl = NSRunLoop.currentRunLoop()
            while self.scanning:
                rl.runUntilDate_(NSDate.dateWithTimeIntervalSinceNow_(0.2))
        except Exception as e:
            Clock.schedule_once(lambda dt: self.log(str(e)), 0)


class BleBridgeApp(App):
    def build(self):
        Window.clearcolor = get_color_from_hex("#222222")
        return GUI()


if __name__ == "__main__":
    BleBridgeApp().run()
