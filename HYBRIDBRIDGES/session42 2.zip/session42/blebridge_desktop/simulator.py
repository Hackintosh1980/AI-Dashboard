#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sim_thb.py – ThermoBeacon TB2 Simulator
Schreibt NUR eine Datei: ./data/ble_dump.json
© 2025 Dominik Rosenthal
"""

import os
import json
import time
import random
from datetime import datetime, timezone

# ------------------------------------------------------------
# Speicherort (EXAKT wie deine Desktop-Bridges)
# ------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.abspath(os.path.join(BASE_DIR, ".."))
DATA_DIR = os.path.join(PROJECT_DIR, "data")
OUT_FILE = os.path.join(DATA_DIR, "ble_dump.json")


# ------------------------------------------------------------
# Hilfsfunktionen
# ------------------------------------------------------------
def ts():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "+0000"


def tb2_raw(t_i, h_i, t_e, h_e, pkt):
    """
    Baut einen echten TB2-RAW-String (Manufacturer Data 0x0019)
    """
    def enc(v):
        x = int(v * 16)
        if x < 0:
            x = (1 << 16) + x
        return [x & 0xFF, (x >> 8) & 0xFF]

    b = []
    b += [0x19, 0x00]                       # Company ID
    b += [0xAA,0xBB,0xCC,0xDD,0xEE,0xFF]    # dummy
    b += [0x02,0x00]                        # Flag "internal + external"
    b += enc(t_i)
    b += enc(h_i)
    b += enc(t_e)
    b += enc(h_e)
    b += [pkt & 0xFF]

    return "".join(f"{x:02X}" for x in b)


# ------------------------------------------------------------
# Sim-Sensoren
# ------------------------------------------------------------
SENSORS = [
    ("Sim-THB-A", "AA:BB:CC:11:22:01"),
    ("Sim-THB-B", "AA:BB:CC:11:22:02"),
    ("Sim-THB-C", "AA:BB:CC:11:22:03"),
]

pkt = 0

print("[Simulator] START – schreibt TB2-kompatible Daten nach:")
print("             ", OUT_FILE)


# ------------------------------------------------------------
# Main Loop (läuft ENDLOS bis SIGTERM)
# ------------------------------------------------------------
while True:
    pkt = (pkt + 1) % 255

    arr = []
    for name, addr in SENSORS:

        # zufällige Werte
        t_i = 20 + random.uniform(-0.5, 0.5)
        h_i = 50 + random.uniform(-2, 2)
        t_e = 19 + random.uniform(-0.4, 0.4)
        h_e = 48 + random.uniform(-3, 3)

        raw = tb2_raw(t_i, h_i, t_e, h_e, pkt)

        arr.append({
            "timestamp": ts(),
            "name": name,
            "address": addr,
            "rssi": random.randint(-85, -40),
            "raw": raw,
            "note": "simulated"
        })

    # atomar schreiben
    tmp = OUT_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(arr, f, indent=2)

    os.replace(tmp, OUT_FILE)

    time.sleep(1.5)
