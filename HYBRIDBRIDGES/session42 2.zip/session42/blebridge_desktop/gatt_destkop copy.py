#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
blebridge_desktop_gatt_tp.py – Active GATT Bridge for ThermoPro NEW model
© 2025 Dominik Rosenthal
"""

import json, time, threading, os
from datetime import datetime, timezone

from Foundation import NSObject, NSRunLoop, NSDate
import CoreBluetooth as CB

# --- Pfade exakt wie in deiner bisherigen Desktop Bridge ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(BASE_DIR)
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
OUT_FILE = os.path.join(DATA_DIR, "ble_dump.json")

# ThermoPro NEW GATT characteristic UUID (Notifications)
TP_SERVICE = "00010203-0405-0607-0809-0a0b0c0d1910"
TP_CHAR    = "00010203-0405-0607-0809-0a0b0c0d2b10"

def ts_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "+0000"


class Store:
    """Speichert EIN Gerät sauber als JSON für ble_dump.json"""
    def __init__(self):
        self.lock = threading.Lock()
        self.entry = None

    def update(self, value_hex, name, address, rssi):
        with self.lock:
            self.entry = dict(
                timestamp=ts_iso(),
                name=name,
                address=address,
                rssi=rssi,
                raw=value_hex.upper(),
                note="gatt"
            )

    def snapshot(self):
        with self.lock:
            return [self.entry] if self.entry else []


class WriterThread(threading.Thread):
    def __init__(self, store):
        super().__init__(daemon=True)
        self.store = store
        os.makedirs(DATA_DIR, exist_ok=True)
        self.running = True

    def run(self):
        while self.running:
            data = self.store.snapshot()
            tmp = OUT_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, OUT_FILE)
            time.sleep(1.0)

    def stop(self):
        self.running = False


class TPDelegate(NSObject):
    """CBCentralManager + Notification Delegate"""

    def initWithStore_(self, store):
        self = self.init()
        if self is None:
            return None
        self.store = store
        self.manager = None
        self.peripheral = None
        return self

    def centralManagerDidUpdateState_(self, manager):
        if manager.state() == CB.CBManagerStatePoweredOn:
            print("[GATT] Scan starting…")
            manager.scanForPeripheralsWithServices_options_(None, None)
        else:
            print("BT State:", manager.state())

    def centralManager_didDiscoverPeripheral_advertisementData_RSSI_(self, m, p, adv, rssi):
        name = adv.get(CB.CBAdvertisementDataLocalNameKey) or p.name() or ""
        if "TP" in name or "Thermo" in name:
            print("[GATT] Found ThermoPro:", name)
            self.manager.stopScan()
            self.peripheral = p
            self.manager.connectPeripheral_options_(p, None)

    def centralManager_didConnectPeripheral_(self, m, p):
        print("[GATT] Connected → discovering services…")
        p.setDelegate_(self)
        p.discoverServices_()

    def peripheral_didDiscoverServices_(self, p, err):
        for s in p.services():
            if s.UUID().UUIDString().lower() == TP_SERVICE:
                p.discoverCharacteristics_forService_(None, s)

    def peripheral_didDiscoverCharacteristicsForService_error_(self, p, s, err):
        for ch in s.characteristics():
            if ch.UUID().UUIDString().lower() == TP_CHAR:
                print("[GATT] Subscribing notifications…")
                p.setNotifyValue_forCharacteristic_(True, ch)

    def peripheral_didUpdateValueForCharacteristic_error_(self, p, ch, err):
        raw = bytes(ch.value()).hex()
        addr = str(p.identifier())
        rssi = p.RSSI() if hasattr(p, "RSSI") else 0
        name = p.name() or "ThermoPro"

        print("[GATT] Notification:", raw)

        self.store.update(raw, name, addr, rssi)


def main():
    print("[GATT BRIDGE] START – ThermoPro direct GATT mode")

    store = Store()
    writer = WriterThread(store)
    writer.start()

    delegate = TPDelegate.alloc().initWithStore_(store)
    manager = CB.CBCentralManager.alloc().initWithDelegate_queue_options_(delegate, None, None)
    delegate.manager = manager

    rl = NSRunLoop.currentRunLoop()

    try:
        while True:
            rl.runUntilDate_(NSDate.dateWithTimeIntervalSinceNow_(0.1))
            time.sleep(0.05)
    except KeyboardInterrupt:
        pass
    finally:
        writer.stop()
        print("[GATT BRIDGE] STOP")


if __name__ == "__main__":
    main()
