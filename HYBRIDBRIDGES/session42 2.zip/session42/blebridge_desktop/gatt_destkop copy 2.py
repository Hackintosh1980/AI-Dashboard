#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gatt_destkop.py – Direct GATT Bridge für ThermoPro TP351S
© 2025 Dominik Rosenthal
"""

import os
import json
import time
import threading
from datetime import datetime, timezone

from Foundation import NSObject, NSRunLoop, NSDate
import CoreBluetooth as CB

# --- Pfade exakt wie bei deinen anderen Desktop-Bridges ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(BASE_DIR)
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
OUT_FILE = os.path.join(DATA_DIR, "ble_dump.json")

# nur der neue ThermoPro
TP_NAME_KEYWORDS = ("TP351", "TP351S", "TP", "Thermo")

# Service/Char vom TP351S (aus nRF Connect)
TP_SERVICE_UUID = "00010203-0405-0607-0809-0a0b0c0d1910".lower()
TP_CHAR_UUID    = "00010203-0405-0607-0809-0a0b0c0d2b10".lower()

WRITE_INTERVAL = 1.0


def ts_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "+0000"


class Store:
    """Speichert genau EIN ThermoPro-GATT-Gerät im ble_dump-Format."""
    def __init__(self):
        self.lock = threading.Lock()
        self.entry = None

    def update(self, value_hex: str, name: str, address: str, rssi: int):
        with self.lock:
            self.entry = {
                "timestamp": ts_iso(),
                "name": name,
                "address": address,
                "rssi": int(rssi),
                "raw": value_hex.upper(),
                "note": "gatt",
            }

    def snapshot(self):
        with self.lock:
            return [self.entry] if self.entry else []


class WriterThread(threading.Thread):
    def __init__(self, store: Store):
        super().__init__(daemon=True)
        self.store = store
        self.running = True
        os.makedirs(DATA_DIR, exist_ok=True)

    def run(self):
        while self.running:
            data = self.store.snapshot()
            tmp = OUT_FILE + ".tmp"
            try:
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                os.replace(tmp, OUT_FILE)
            except Exception as e:
                print("[GATT][WRITE] Fehler:", e)
            time.sleep(WRITE_INTERVAL)

    def stop(self):
        self.running = False


class TPDelegate(NSObject):
    """Central & Peripheral Delegate für ThermoPro TP351S (CoreBluetooth)."""

    # ----- Init -----
    def initWithStore_(self, store):
        self = self.init()
        if self is None:
            return None
        self.store = store
        self.manager = None
        self.peripheral = None
        self.tp_char = None
        return self

    # ----- Central Delegate -----
    def centralManagerDidUpdateState_(self, manager):
        state = manager.state()
        if state == CB.CBManagerStatePoweredOn:
            print("[GATT] Bluetooth ON → Scan startet…")
            # alle Devices scannen, wir filtern auf Namen
            manager.scanForPeripheralsWithServices_options_(None, None)
        else:
            print("[GATT] Bluetooth State:", state)

    def centralManager_didDiscoverPeripheral_advertisementData_RSSI_(
        self, central, peripheral, adv, rssi
    ):
        try:
            name = adv.get(CB.CBAdvertisementDataLocalNameKey) or peripheral.name() or ""
        except Exception:
            name = peripheral.name() or ""

        lname = (name or "").upper()
        if any(k in lname for k in TP_NAME_KEYWORDS):
            print(f"[GATT] Found ThermoPro: {name}")
            self.manager.stopScan()
            self.peripheral = peripheral
            self.manager.connectPeripheral_options_(peripheral, None)

    def centralManager_didConnectPeripheral_(self, central, peripheral):
        print("[GATT] Connected → discovering services…")
        peripheral.setDelegate_(self)
        # alle Services entdecken
        peripheral.discoverServices_(None)

    # ----- Peripheral Delegate -----
    # CBPeripheralDelegate: peripheral:didDiscoverServices:
    def peripheral_didDiscoverServices_(self, peripheral, error):
        if error is not None:
            print("[GATT] Service-Discovery-Fehler:", error)
            return

        services = peripheral.services() or []
        print(f"[GATT] {len(services)} Services gefunden")

        for s in services:
            try:
                suuid = s.UUID().UUIDString().lower()
            except Exception:
                continue

            if suuid == TP_SERVICE_UUID:
                print("[GATT] ThermoPro Service gefunden → discoverCharacteristics")
                peripheral.discoverCharacteristics_forService_(None, s)
                return

        print("[GATT] ThermoPro Service NICHT gefunden")

    # CBPeripheralDelegate: peripheral:didDiscoverCharacteristicsForService:error:
    def peripheral_didDiscoverCharacteristicsForService_error_(self, peripheral, service, error):
        if error is not None:
            print("[GATT] Characteristic-Discovery-Fehler:", error)
            return

        chars = service.characteristics() or []
        print(f"[GATT] {len(chars)} Characteristics im ThermoPro Service")

        for ch in chars:
            try:
                cuuid = ch.UUID().UUIDString().lower()
            except Exception:
                continue

            if cuuid == TP_CHAR_UUID:
                self.tp_char = ch
                print("[GATT] TP351S Notify-Characteristic gefunden → subscribe")
                peripheral.setNotifyValue_forCharacteristic_(True, ch)
                return

        print("[GATT] TP351S Notify-Characteristic NICHT gefunden")

    # CBPeripheralDelegate: peripheral:didUpdateValueForCharacteristic:error:
    def peripheral_didUpdateValueForCharacteristic_error_(self, peripheral, characteristic, error):
        if error is not None:
            print("[GATT] Notification-Fehler:", error)
            return

        try:
            value = bytes(characteristic.value()).hex()
        except Exception as e:
            print("[GATT] Hex-Konvertierungs-Fehler:", e)
            return

        addr = str(peripheral.identifier())
        name = peripheral.name() or "ThermoPro"
        # RSSI ist bei GATT auf macOS nicht direkt als Methode verfügbar → 0
        rssi = 0

        print(f"[GATT] Notification RAW: {value}")
        self.store.update(value, name, addr, rssi)


def main():
    print("[GATT BRIDGE] START – ThermoPro Direct GATT → ble_dump.json")

    store = Store()
    writer = WriterThread(store)
    writer.start()

    delegate = TPDelegate.alloc().initWithStore_(store)
    manager = CB.CBCentralManager.alloc().initWithDelegate_queue_options_(delegate, None, None)
    delegate.manager = manager

    rl = NSRunLoop.currentRunLoop()

    try:
        while True:
            rl.runUntilDate_(NSDate.dateWithTimeIntervalSinceNow_(0.1))
            time.sleep(0.05)
    except KeyboardInterrupt:
        print("\n[GATT] KeyboardInterrupt – stop.")
    finally:
        writer.stop()
        print("[GATT BRIDGE] STOP")


if __name__ == "__main__":
    main()
