#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
tb2_ble_multisim.py
MULTI-DEVICE BLE BROADCASTER (ThermoBeacon TB2 RAW)

Simuliert 10, 20 oder 100 TB2 Geräte gleichzeitig über Bluetooth LE.
Android erkennt sie wie echte Sensoren.
"""

import asyncio
from bleak.backends.bluezdbus.advertisement import Advertisement
from bleak.backends.bluezdbus import BleakGATTServerLinux

CID = 0x0019  # ThermoBeacon Company ID

# ----------------------------------------------------------
# 1) Liste aller Geräte (MAC irrelevant für BLE-Beacon)
# ----------------------------------------------------------
DEVICES_RAW = [
    # Hier trägst du beliebige RAW-Hex aus deinem sim_tile_tester_pro.py ein
    "1900AABBCCDDEEFF02004001FF0FFF0FFF0FA6",
    "1900AABBCCDDEEFF02004601FF0FFF0FFF0FA6",
    "1900AABBCCDDEEFF02004A01FF0FFF0FFF0FA6",
    "1900AABBCCDDEEFF02003C01FF0FFF0FFF0FA6",
    "1900AABBCCDDEEFF02004801FF0FFF0FFF0FA6",
]

# ----------------------------------------------------------
# 2) Erzeuge BLE-Adverts
# ----------------------------------------------------------
class TB2Advert(Advertisement):
    def __init__(self, raw, idx):
        super().__init__("peripheral")
        self.local_name = f"TB2-Sim-{idx:02d}"
        self.manufacturer_data = {CID: bytes.fromhex(raw)}

async def main():
    servers = []

    print("\n[TB2-SIM] Starte Multi-BLE-Broadcasting…")
    for i, raw in enumerate(DEVICES_RAW, 1):
        adv = TB2Advert(raw, i)
        srv = BleakGATTServerLinux()
        await srv.start_advertising(adv)
        servers.append(srv)
        print(f"  → Gerät {i:02d} sendet RAW:", raw)

    print("\n[TB2-SIM] ALLE GERÄTE SENDEN!  🚀")
    print("Android erkennt jetzt alle als echte TB2-Sensoren.\n")

    # Block forever
    await asyncio.Event().wait()

asyncio.run(main())
