#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
sim_tile_tester_pro.py
Ultimate Tile Test Simulator (bereinigte Version)

Erzeugt 22 Geräte in festen Modi:
- temp_only      → 1 Tile (nur Temperatur)
- temp_hum       → 2 Tiles (Temp + Hum intern)
- temp_hum_ext   → 3 Tiles (Temp + Hum intern + extern)
- ultra_stable   → minimaler Drift (Referenz für Graphen)
- chaos          → wilde, aber gültige Werte (Tile-Rebuild-Test)
- external_only  → nur Extern-Sonde
- humidity_only  → nur Luftfeuchte

RAW = TB2-kompatibel → FULL Decoder-Kompatibilität.
"""

import os
import json
import random
import time
from datetime import datetime, timezone

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(os.path.dirname(BASE), "data")
OUT = os.path.join(DATA, "ble_dump.json")
os.makedirs(DATA, exist_ok=True)


def ts():
    return (
        datetime.now(timezone.utc)
        .strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]
        + "+0000"
    )


# ---------------------------------------------------------
# TB2 RAW Encoder (mit sauberem Null-Handling)
# ---------------------------------------------------------
def tb2_raw(temp_i, hum_i, temp_e, hum_e, pkt):
    def enc(v):
        """TB2-16bit-Feld encoden, None → 0x0FFF (Nullwert)."""
        if v is None:
            return [0xFF, 0x0F]  # 0x0FFF = 'keine Daten'

        # clamp für sinnvolle Wertebereiche bevor wir encoden
        # Temp: -40..85, Hum: 0..100 (nur als Safety-Net)
        if isinstance(v, (int, float)):
            # hier kein hartes Clamping nötig, aber wir könnten:
            # v = max(-40.0, min(85.0, v))
            pass

        x = int(round(v * 16.0))
        if x < 0:
            x = (1 << 16) + x
        return [x & 0xFF, (x >> 8) & 0xFF]

    b = []
    b += [0x19, 0x00]  # Company ID (ThermoBeacon)
    b += [0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF]  # Dummy-MAC (wird im JSON gesetzt)
    b += [0x02, 0x00]  # Flags

    b += enc(temp_i)
    b += enc(hum_i)
    b += enc(temp_e)
    b += enc(hum_e)
    b += [pkt & 0xFF]

    return "".join(f"{x:02X}" for x in b)


# ---------------------------------------------------------
# DEVICE LIST — 22 Geräte
# ---------------------------------------------------------
DEVICES = []

# 5 temp_only
for i in range(1, 6):
    DEVICES.append(
        (f"TempOnly-{i:02d}", f"AA:BB:CC:00:10:{i:02d}", "temp_only")
    )

# 5 temp_hum
for i in range(1, 6):
    DEVICES.append(
        (f"TempHum-{i:02d}", f"AA:BB:CC:00:20:{i:02d}", "temp_hum")
    )

# 5 temp_hum_ext
for i in range(1, 6):
    DEVICES.append(
        (f"TempHumExt-{i:02d}", f"AA:BB:CC:00:30:{i:02d}", "temp_hum_ext")
    )

# 3 ultra_stable
for i in range(1, 4):
    DEVICES.append(
        (f"Stable-{i:02d}", f"AA:BB:CC:00:40:{i:02d}", "ultra_stable")
    )

# 2 chaos
for i in range(1, 3):
    DEVICES.append(
        (f"Chaos-{i:02d}", f"AA:BB:CC:00:50:{i:02d}", "chaos")
    )

# 1 external_only
DEVICES.append(
    ("ExternalOnly-01", "AA:BB:CC:00:60:01", "external_only")
)

# 1 humidity_only
DEVICES.append(
    ("HumidityOnly-01", "AA:BB:CC:00:70:01", "humidity_only")
)

pkt = 0
print("[TileSim PRO] schreibt →", OUT)


# Helper zum Clampen (vor Chaos)
def clamp(v, lo, hi):
    return max(lo, min(hi, v))


# ---------------------------------------------------------
# MAIN LOOP
# ---------------------------------------------------------
while True:
    pkt = (pkt + 1) % 255
    arr = []

    for name, mac, mode in DEVICES:

        # ------------------------ MODES ------------------------

        if mode == "temp_only":
            # 1 Tile: nur Temperatur
            t_i = 20.0 + random.uniform(-0.7, 0.7)
            h_i = None
            t_e = None
            h_e = None

        elif mode == "temp_hum":
            # 2 Tiles: Temp + Hum intern
            t_i = 21.0 + random.uniform(-1.0, 1.0)
            h_i = 45.0 + random.uniform(-3.0, 3.0)
            t_e = None
            h_e = None

        elif mode == "temp_hum_ext":
            # 3 Tiles: intern + extern aktiv
            t_i = 23.0 + random.uniform(-1.0, 1.0)
            h_i = 55.0 + random.uniform(-4.0, 4.0)
            t_e = t_i - 1.2 + random.uniform(-0.3, 0.3)
            h_e = h_i - 7.0 + random.uniform(-2.0, 2.0)

        elif mode == "ultra_stable":
            # Referenzsignal: fast gerade Linien
            t_i = 24.0 + random.uniform(-0.05, 0.05)
            h_i = 50.0 + random.uniform(-0.2, 0.2)
            t_e = None
            h_e = None

        elif mode == "chaos":
            # Gültig, aber wild (nachträglich geclamped)
            t_i = clamp(20.0 + random.uniform(-8.0, 8.0), 10.0, 35.0)
            h_i = clamp(50.0 + random.uniform(-30.0, 30.0), 10.0, 90.0)
            if random.random() < 0.5:
                t_e = clamp(t_i - random.uniform(1.0, 5.0), 5.0, 35.0)
                h_e = clamp(h_i - random.uniform(5.0, 20.0), 5.0, 95.0)
            else:
                t_e = None
                h_e = None

        elif mode == "external_only":
            # Nur externe Sonde (intern = None)
            t_i = None
            h_i = None
            t_e = 18.0 + random.uniform(-1.0, 1.0)
            h_e = 40.0 + random.uniform(-4.0, 4.0)

        elif mode == "humidity_only":
            # Nur Luftfeuchte intern (Temp = None)
            t_i = None
            h_i = 60.0 + random.uniform(-5.0, 5.0)
            t_e = None
            h_e = None

        else:
            # Fallback – sollte nie passieren
            t_i = 22.0
            h_i = 50.0
            t_e = None
            h_e = None

        raw = tb2_raw(t_i, h_i, t_e, h_e, pkt)

        arr.append(
            {
                "timestamp": ts(),
                "name": name,
                "address": mac,
                "rssi": random.randint(-85, -40),
                "raw": raw,
            }
        )

    # atomar write
    tmp = OUT + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(arr, f, indent=2)
    os.replace(tmp, OUT)

    time.sleep(1.2)
