#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gatt_destkop.py – Direct GATT Bridge for ThermoPro TP351
© 2025 Dominik Rosenthal
"""

import json
import os
import threading
import time
from datetime import datetime, timezone

from Foundation import NSObject, NSRunLoop, NSDate
import CoreBluetooth as CB

# --- Pfade exakt wie bei deiner Smooth-Bridge ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(BASE_DIR)
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
OUT_FILE = os.path.join(DATA_DIR, "ble_dump.json")

# ThermoPro GATT Service/Char (Notifications)
TP_SERVICE = "00010203-0405-0607-0809-0a0b0c0d1910".lower()
TP_CHAR = "00010203-0405-0607-0809-0a0b0c0d2b10".lower()


def ts_iso():
    return (
        datetime.now(timezone.utc)
        .strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]
        + "+0000"
    )


class Store:
    """
    Hält genau EIN aktuelles Paket vom TP351
    und gibt es als Liste für ble_dump.json aus.
    """

    def __init__(self):
        self.lock = threading.Lock()
        self.entry = None

    def update(self, value_hex, name, address, rssi):
        with self.lock:
            self.entry = dict(
                timestamp=ts_iso(),
                name=name,
                address=address,
                rssi=int(rssi),
                raw=value_hex.upper(),
                note="gatt_tp351",
            )

    def snapshot(self):
        with self.lock:
            return [self.entry] if self.entry else []


class WriterThread(threading.Thread):
    def __init__(self, store):
        super().__init__(daemon=True)
        self.store = store
        self.running = True
        os.makedirs(DATA_DIR, exist_ok=True)

    def run(self):
        while self.running:
            data = self.store.snapshot()
            tmp = OUT_FILE + ".tmp"
            try:
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                os.replace(tmp, OUT_FILE)
            except Exception as e:
                print("[GATT] Write error:", e)
            time.sleep(1.0)

    def stop(self):
        self.running = False


class ThermoGattDelegate(NSObject):
    """
    Ein Delegate für CBCentralManager + CBPeripheral
    – scannt alle ADV-Pakete,
      verbindet bei TP351,
      abonniert Notifications und
      schreibt in Store.
    """

    def initWithStore_(self, store):
        self = self.init()
        if self is None:
            return None
        self.store = store
        self.manager = None
        self.tp_peripheral = None
        self.notify_char = None
        self.last_rssi = 0
        return self

    # ---------- Central Manager ----------

    def centralManagerDidUpdateState_(self, manager):
        state = manager.state()
        if state == CB.CBManagerStatePoweredOn:
            print("[GATT] Bluetooth ON → Scan startet…")
            # Alle Devices scannen, Duplicates erlaubt
            manager.scanForPeripheralsWithServices_options_(
                None, {"kCBScanOptionAllowDuplicatesKey": True}
            )
        else:
            print("[GATT] Bluetooth state:", state)

    def centralManager_didDiscoverPeripheral_advertisementData_RSSI_(
        self, central, peripheral, adv, rssi
    ):
        name = adv.get(CB.CBAdvertisementDataLocalNameKey) or peripheral.name() or ""
        msd = adv.get(CB.CBAdvertisementDataManufacturerDataKey)
        raw = bytes(msd).hex().upper() if msd else ""

        print(f"[TP351] ADV '{name}' RSSI {rssi} raw={raw}")

        # Nur einmal TP351/TP351S auswählen
        if self.tp_peripheral is None and (
            "TP351" in name or "TP351S" in name or ("TP" in name and "351" in name)
        ):
            print(f"[GATT] Found ThermoPro: {name}")
            self.tp_peripheral = peripheral
            self.last_rssi = int(rssi)
            self.manager.stopScan()
            self.manager.connectPeripheral_options_(peripheral, None)

    def centralManager_didConnectPeripheral_(self, central, peripheral):
        print("[GATT] Verbunden → Services suchen…")
        peripheral.setDelegate_(self)
        # Optional: RSSI aktualisieren (async)
        try:
            peripheral.readRSSI()
        except Exception:
            pass
        peripheral.discoverServices_(None)

    def centralManager_didFailToConnectPeripheral_error_(
        self, central, peripheral, error
    ):
        print("[GATT] Verbindung fehlgeschlagen:", error)

    def centralManager_didDisconnectPeripheral_error_(
        self, central, peripheral, error
    ):
        print("[GATT] Getrennt:", error)
        # Wir bleiben in diesem Lauf einfach getrennt; kein Auto-Reconnect jetzt.

    # ---------- Peripheral Delegate ----------

    def peripheral_didReadRSSI_error_(self, peripheral, rssi, error):
        if error is None:
            try:
                self.last_rssi = int(rssi)
            except Exception:
                pass

    def peripheral_didDiscoverServices_(self, peripheral, error):
        if error is not None:
            print("[GATT] Service-Discovery Fehler:", error)
            return

        services = peripheral.services() or []
        print(f"[GATT] {len(services)} Services gefunden")

        for s in services:
            uuid_str = s.UUID().UUIDString().lower()
            if uuid_str == TP_SERVICE:
                print("[GATT] ThermoPro Service gefunden → Characteristics suchen…")
                peripheral.discoverCharacteristics_forService_(None, s)
                return

        print("[GATT] ThermoPro Service nicht gefunden")

    def peripheral_didDiscoverCharacteristicsForService_error_(
        self, peripheral, service, error
    ):
        if error is not None:
            print("[GATT] Char-Discovery Fehler:", error)
            return

        chars = service.characteristics() or []
        print(f"[GATT] {len(chars)} Characteristics im ThermoPro-Service")

        for ch in chars:
            uuid_str = ch.UUID().UUIDString().lower()
            if uuid_str == TP_CHAR:
                print("[GATT] Notify-Char gefunden → Notifications aktivieren…")
                self.notify_char = ch
                peripheral.setNotifyValue_forCharacteristic_(True, ch)

    def peripheral_didUpdateNotificationStateForCharacteristic_error_(
        self, peripheral, characteristic, error
    ):
        if error is not None:
            print("[GATT] Notify-State Fehler:", error)
            return
        enabled = characteristic.isNotifying()
        print(f"[GATT] Notify-State: {'AN' if enabled else 'AUS'}")

    def peripheral_didUpdateValueForCharacteristic_error_(
        self, peripheral, characteristic, error
    ):
        if error is not None:
            print("[GATT] Value-Update Fehler:", error)
            return

        if characteristic.UUID().UUIDString().lower() != TP_CHAR:
            return

        data = characteristic.value()
        if not data:
            print("[GATT] Leeres Notify-Paket")
            return

        payload = bytes(data)
        raw_hex = payload.hex().upper()
        name = peripheral.name() or "TP351"
        addr = str(peripheral.identifier())
        rssi = self.last_rssi

        print(f"[GATT] Notify von {name}: {raw_hex}")
        self.store.update(raw_hex, name, addr, rssi)


def main():
    print("[GATT BRIDGE] START – ThermoPro Direct GATT → ble_dump.json")

    store = Store()
    writer = WriterThread(store)
    writer.start()

    delegate = ThermoGattDelegate.alloc().initWithStore_(store)
    manager = CB.CBCentralManager.alloc().initWithDelegate_queue_options_(
        delegate, None, None
    )
    delegate.manager = manager

    rl = NSRunLoop.currentRunLoop()

    try:
        while True:
            rl.runUntilDate_(NSDate.dateWithTimeIntervalSinceNow_(0.1))
            time.sleep(0.05)
    except KeyboardInterrupt:
        pass
    finally:
        writer.stop()
        print("[GATT BRIDGE] STOP")


if __name__ == "__main__":
    main()
