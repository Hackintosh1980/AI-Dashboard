#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
decoder.py – Session40 + per-Device stale_timeout

Kompatibel zum NEUEN config-Format:

config["devices"] = {
    "MAC1": { "profile": "tb2" },
    "MAC2": { "profile": "tpro" }
}

- Kein globales profile mehr.
- Kein device_profiles mehr.
- stale_timeout wird PRO DEVICE ausgewertet.
"""

import os
import json
import time
import threading
import csv

from kivy.utils import platform
import config
import calculator

# ------------------------------------------------------------
# PFAD-LOGIK
# ------------------------------------------------------------
BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")

RAW_FILE = None
DEC_FILE = None
CSV_FILE = None
PROFILES = None

if platform == "android":
    try:
        from jnius import autoclass
        PythonActivity = autoclass("org.kivy.android.PythonActivity")
        ctx = PythonActivity.mActivity

        FILES = ctx.getFilesDir().getAbsolutePath()
        APP_ROOT = os.path.join(FILES, "app")
        DATA = os.path.join(APP_ROOT, "data")

        RAW_FILE = os.path.join(FILES, "ble_dump.json")
        DEC_FILE = os.path.join(DATA, "decoded.json")
        PROFILES = os.path.join(DATA, "decoder_profiles")
    except Exception:
        RAW_FILE = os.path.join(DATA, "ble_dump.json")
        DEC_FILE = os.path.join(DATA, "decoded.json")
        PROFILES = os.path.join(DATA, "decoder_profiles")
else:
    RAW_FILE = os.path.join(DATA, "ble_dump.json")
    DEC_FILE = os.path.join(DATA, "decoded.json")
    PROFILES = os.path.join(DATA, "decoder_profiles")

CSV_FILE = os.path.join(os.path.dirname(DEC_FILE), "log.csv")

os.makedirs(os.path.dirname(DEC_FILE), exist_ok=True)
os.makedirs(PROFILES, exist_ok=True)

print("[Decoder] Paths OK:")
print(" RAW_FILE:", RAW_FILE)
print(" DEC_FILE:", DEC_FILE)
print(" CSV_FILE:", CSV_FILE)
print(" PROFILES:", PROFILES)

# ------------------------------------------------------------
# BRIDGE STATE (vom Core gesetzt)
# ------------------------------------------------------------
BRIDGE_ALIVE = True
BRIDGE_STATUS = "OK"
BRIDGE_LAST_SEEN = None
UPTIME_START = None


def update_bridge_state(alive, status, last_seen):
    global BRIDGE_ALIVE, BRIDGE_STATUS, BRIDGE_LAST_SEEN
    BRIDGE_ALIVE = alive
    BRIDGE_STATUS = status
    BRIDGE_LAST_SEEN = last_seen


# ------------------------------------------------------------
# INTERNER STALE-STATE PRO DEVICE
# ------------------------------------------------------------
_LAST_RAW = {}   # mac -> raw_hex
_LAST_TS = {}    # mac -> timestamp


# ------------------------------------------------------------
# PROFILE LOAD
# ------------------------------------------------------------
def load_profile(name: str):
    """Lädt Profil by name → erwartet <name>.json in decoder_profiles."""
    fname = f"{name}.json"

    p1 = os.path.join(PROFILES, fname)
    p2 = os.path.join(BASE, "decoder_profiles", fname)

    for path in (p1, p2):
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    prof = json.load(f)
                # nur Profile mit 'fields' akzeptieren – leere Profile sind ungültig
                if isinstance(prof, dict) and prof.get("fields"):
                    return prof
                print("[Decoder] Ungültiges Profil:", path)
                return None
            except Exception:
                print("[Decoder] Profil-Ladefehler:", path)
                return None

    print("[Decoder] Profil fehlt:", fname)
    return None


# ------------------------------------------------------------
# RAW decode
# ------------------------------------------------------------
def _le16(b, pos):
    if pos + 1 >= len(b):
        return None
    v = b[pos] | (b[pos + 1] << 8)
    if v in (0x0FFF, 0xFFFF):
        return None
    if v & 0x8000:
        v -= 0x10000
    return v


def decode_with_profile(entry, prof):
    """Dekodiert einen Eintrag anhand des Profils.
       Profil MUSS 'fields' haben, sonst None → offline."""
    raw_hex = entry.get("raw") or ""
    if not raw_hex:
        return None

    # Profil ohne fields → KEIN Decode
    fields = prof.get("fields")
    if not isinstance(fields, dict):
        return None

    try:
        b = bytes.fromhex(raw_hex)
    except Exception:
        return None

    # Company-ID (mit Default wie im alten Decoder)
    company_id = int(prof.get("company_id", 25))

    # aktuelle CID aus dem Paket
    cid = (b[1] << 8) | b[0] if len(b) >= 2 else -1

    # Company-ID erzwingen: wenn anders, vorne dranhängen
    if cid != company_id:
        msd = bytearray(2 + len(b))
        msd[0] = company_id & 0xFF
        msd[1] = (company_id >> 8) & 0xFF
        msd[2:] = b
        b = bytes(msd)

    mac_len = int(prof.get("mac_len", 6))
    skip = int(prof.get("skip_after_mac", 2))
    pos = 2 + mac_len + skip

    # Feldoffsets – hier knallhart: fehlen T_i/H_i/... → kein Decode
    try:
        off_Ti = int(fields.get("T_i", 0))
        off_Hi = int(fields.get("H_i", 2))
        off_Te = int(fields.get("T_e", 4))
        off_He = int(fields.get("H_e", 6))
        off_pkt = int(fields.get("packet", 8))
    except Exception:
        return None

    try:
        ti = _le16(b, pos + off_Ti)
        hi = _le16(b, pos + off_Hi)
        te = _le16(b, pos + off_Te)
        he = _le16(b, pos + off_He)
        pkt = b[pos + off_pkt]
    except Exception:
        return None

    scaleT = float(prof.get("scale_temperature", 16))
    scaleH = float(prof.get("scale_humidity", 16))

    return {
        "timestamp": entry.get("timestamp"),
        "device_id": entry.get("address"),
        "raw": raw_hex,
        "name": entry.get("name"),
        "rssi": entry.get("rssi"),
        "packet_counter": int(pkt),
        "T_i": ti / scaleT if ti is not None else None,
        "H_i": hi / scaleH if hi is not None else None,
        "T_e": te / scaleT if te is not None else None,
        "H_e": he / scaleH if he is not None else None,
    }


# ------------------------------------------------------------
# OFFLINE FRAME
# ------------------------------------------------------------
def offline_frame(mac, prof):
    unit = f"°{config.get_temperature_unit().upper()}"

    if not isinstance(prof, dict):
        prof = {}

    return {
        "timestamp": None,
        "device_id": mac,
        "name": None,
        "rssi": None,
        "packet_counter": None,

        "sensor": {
            "vendor": prof.get("vendor", "Unknown"),
            "model": prof.get("model", "Unknown"),
            "type": "temperature_humidity",
        },

        "internal": {
            "temperature": {"value": None, "unit": unit},
            "humidity": {"value": None, "unit": "%"},
        },

        "external": {
            "present": False,
            "temperature": {"value": None, "unit": unit},
            "humidity": {"value": None, "unit": "%"},
        },

        "vpd_internal": {"value": None, "unit": "kPa"},
        "vpd_external": {"value": None, "unit": "kPa"},

        "alive": False,
        "status": "offline",
        "last_seen": BRIDGE_LAST_SEEN,
        "raw": None,
        "bridge_alive": BRIDGE_ALIVE,
        "bridge_status": BRIDGE_STATUS,
        "bridge_last_seen": BRIDGE_LAST_SEEN,

        "health": {
            "uptime": {"value": None, "unit": "s"},
            "battery": {"value": None, "unit": "%", "voltage": None},
            "signal": {"rssi": None, "quality": None},
        },
    }


def offline_all(cfg):
    out = []
    devs = cfg.get("devices", {})

    if not devs:
        # kein Device → generischer OFFLINE-Eintrag
        out.append(offline_frame(None, {"vendor": "Unknown", "model": "None"}))
        _write(out)
        return

    for mac, d in devs.items():
        name = d.get("profile", "unknown")
        prof = load_profile(name) or {"vendor": "Unknown", "model": name}
        out.append(offline_frame(mac, prof))

    _write(out)


# ------------------------------------------------------------
# MAIN DECODER STEP
# ------------------------------------------------------------
def step_decode():
    global UPTIME_START, _LAST_RAW, _LAST_TS

    cfg = config._init()
    devs = cfg.get("devices", {})

    # KEINE DEVICES?
    if not devs:
        offline_all(cfg)
        return

    # BRIDGE TOT? (aus Watchdog)
    if not BRIDGE_ALIVE:
        offline_all(cfg)
        return

    # RAW FEHLT?
    if not os.path.exists(RAW_FILE):
        offline_all(cfg)
        return

    # RAW LADEN
    try:
        arr = json.load(open(RAW_FILE, "r", encoding="utf-8"))
    except Exception:
        offline_all(cfg)
        return

    if not isinstance(arr, list):
        offline_all(cfg)
        return

    if UPTIME_START is None:
        UPTIME_START = time.time()
    uptime = time.time() - UPTIME_START

    by_mac = {
        e.get("address"): e
        for e in arr
        if isinstance(e, dict) and e.get("address") and e.get("raw")
    }

    unit = f"°{config.get_temperature_unit().upper()}"
    timeout = float(config.get_stale_timeout())
    now = time.time()

    frames = []

    for mac, d in devs.items():
        entry = by_mac.get(mac)
        prof_name = d.get("profile", "unknown")
        prof = load_profile(prof_name)

        # Profil fehlt/kaputt → sofort OFFLINE, KEIN Decode
        if not prof:
            frames.append(offline_frame(mac, {"vendor": "Unknown", "model": prof_name}))
            continue

        # ------------------------------------------------
        # 🔥 STALE-CHECK PRO DEVICE
        # ------------------------------------------------
        stale = False
        if entry:
            raw_hex = entry.get("raw", "")

            last_raw = _LAST_RAW.get(mac)
            last_ts = _LAST_TS.get(mac)

            if last_raw is None or raw_hex != last_raw:
                # neuer Frame → Sensor lebt
                _LAST_RAW[mac] = raw_hex
                _LAST_TS[mac] = now
                stale = False
            else:
                # gleicher RAW → Alter prüfen
                delta = now - (last_ts or now)
                if delta >= timeout:
                    stale = True
        else:
            # gar kein Eintrag im Dump → stale/offline
            last_ts = _LAST_TS.get(mac)
            if last_ts is None:
                stale = True
            else:
                delta = now - last_ts
                if delta >= timeout:
                    stale = True

        if stale:
            frames.append(offline_frame(mac, prof))
            continue

        # ------------------------------------------------
        # LEBEND → normal decoden
        # ------------------------------------------------
        if not entry:
            frames.append(offline_frame(mac, prof))
            continue

        raw = decode_with_profile(entry, prof)
        if not raw:
            frames.append(offline_frame(mac, prof))
            continue

        T_i, H_i, T_e, H_e = calculator.apply_offsets(
            raw["T_i"], raw["H_i"], raw["T_e"], raw["H_e"]
        )

        out_Ti = calculator.to_unit(T_i)
        out_Te = calculator.to_unit(T_e)

        frames.append({
            "timestamp": raw["timestamp"],
            "device_id": mac,
            "name": raw["name"],
            "rssi": raw["rssi"],
            "packet_counter": raw["packet_counter"],

            "sensor": {
                "vendor": prof.get("vendor", "Unknown"),
                "model": prof.get("model", prof_name),
                "type": "temperature_humidity",
            },

            "internal": {
                "temperature": {"value": out_Ti, "unit": unit},
                "humidity": {"value": H_i, "unit": "%"},
            },

            "external": {
                "present": raw["T_e"] is not None,
                "temperature": {"value": out_Te, "unit": unit},
                "humidity": {"value": H_e, "unit": "%"},
            },

            "vpd_internal": {
                "value": calculator.vpd_internal(T_i, H_i),
                "unit": "kPa",
            },
            "vpd_external": {
                "value": calculator.vpd_external(T_e, H_e),
                "unit": "kPa",
            },

            "alive": True,
            "status": "active",
            "last_seen": BRIDGE_LAST_SEEN,
            "raw": raw["raw"],
            "bridge_alive": BRIDGE_ALIVE,
            "bridge_status": BRIDGE_STATUS,
            "bridge_last_seen": BRIDGE_LAST_SEEN,

            "health": {
                "uptime": {"value": uptime, "unit": "s"},
                "battery": {"value": None, "unit": "%", "voltage": None},
                "signal": {"rssi": raw["rssi"], "quality": None},
            },
        })

    _write(frames)


# ------------------------------------------------------------
# CSV + JSON WRITE
# ------------------------------------------------------------
def write_csv(frames):
    if not frames:
        return

    exists = os.path.exists(CSV_FILE)
    os.makedirs(os.path.dirname(CSV_FILE), exist_ok=True)

    with open(CSV_FILE, "a", encoding="utf-8", newline="") as f:
        w = csv.writer(f)

        if not exists:
            w.writerow([
                "timestamp", "device_id", "packet_counter",
                "T_i", "H_i", "T_e", "H_e",
                "rssi", "alive",
            ])

        for fr in frames:
            w.writerow([
                fr.get("timestamp"),
                fr.get("device_id"),
                fr.get("packet_counter"),
                fr.get("internal", {}).get("temperature", {}).get("value"),
                fr.get("internal", {}).get("humidity", {}).get("value"),
                fr.get("external", {}).get("temperature", {}).get("value"),
                fr.get("external", {}).get("humidity", {}).get("value"),
                fr.get("rssi"),
                fr.get("alive"),
            ])


def _write(frames):
    tmp = DEC_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(frames, f, indent=2, ensure_ascii=False)
    os.replace(tmp, DEC_FILE)

    print("[Decoder] decoded.json geschrieben:", DEC_FILE)

    try:
        write_csv(frames)
    except Exception as e:
        print("[Decoder] CSV Fehler:", e)


# ------------------------------------------------------------
# THREAD
# ------------------------------------------------------------
class DecoderThread(threading.Thread):
    def __init__(self, interval=1.0):
        super().__init__(daemon=True)
        self.running = True
        self.interval = interval

    def run(self):
        while self.running:
            step_decode()
            time.sleep(self.interval)

    def stop(self):
        self.running = False


decoder_thread = None


def start_decoder_thread(interval=1.0):
    global decoder_thread
    if decoder_thread:
        return
    decoder_thread = DecoderThread(interval)
    decoder_thread.start()
    print("[Decoder] Thread gestartet")
