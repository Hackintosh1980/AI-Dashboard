#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import time
import config
from kivy.utils import platform

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")

# ------------------------------------------------------------
# 🔧 Plattformabhängiger Pfad (einziger Pfad-Fix)
# ------------------------------------------------------------
def _get_raw_path():
    if platform == "android":
        try:
            from jnius import autoclass
            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            ctx = PythonActivity.mActivity
            files = ctx.getFilesDir().getAbsolutePath()
            return os.path.join(files, "ble_dump.json")
        except Exception:
            pass

    # Desktop / Fallback
    return os.path.join(DATA, "ble_dump.json")


RAW_PATH = _get_raw_path()

# ------------------------------------------------------------
# 🌐 GLOBALER WATCHDOG-STATUS (für Core / Decoder)
# ------------------------------------------------------------
WD_ALIVE = False
WD_STATUS = "OFFLINE"
WD_LAST_SEEN = None


class DumpWatchdog:
    """
    Beobachtet den BLE-Dump für ALLE in config.get_devices()
    eingetragenen Geräte.

    ⚠️ WICHTIG:
      - KEINE Auto-Config mehr
      - KEIN config.save_device_id()
      - KEIN get_device_id()
      - Watchdog speichert NIEMALS in config.json
    """

    def __init__(self, timeout, interval, callback):
        self.timeout = float(timeout)
        self.interval = float(interval)
        self.callback = callback

        # Multi-Geräte-Status
        self._last_raw = {}          # mac -> raw
        self._last_ts = {}           # mac -> timestamp
        self._stale_reported = {}    # mac -> bool

        self.running = False

    def set_timeout(self, t: float):
        self.timeout = float(t)

    # --------------------------------------------------------
    # Dump laden
    # --------------------------------------------------------
    def _load(self):
        if not os.path.exists(RAW_PATH):
            return None
        try:
            with open(RAW_PATH, "r", encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, list) else None
        except Exception:
            return None

    def _find(self, dump, mac):
        for e in dump:
            if isinstance(e, dict) and e.get("address") == mac:
                return e
        return None

    # --------------------------------------------------------
    # Status prüfen – Multi-Device, kein Auto-Save
    # --------------------------------------------------------
    def check_status(self):
        global WD_ALIVE, WD_STATUS, WD_LAST_SEEN

        now = time.time()

        # Nur noch Multi: Liste aus config holen
        try:
            devices = config.get_devices()
        except AttributeError:
            devices = []

        # Keine Geräte konfiguriert → OFFLINE, aber NICHTS speichern
        if not devices:
            WD_ALIVE = False
            WD_STATUS = "OFFLINE"
            WD_LAST_SEEN = None
            return {"alive": False, "last_seen": None, "status": "OFFLINE"}

        dump = self._load()
        if not dump:
            WD_ALIVE = False
            WD_STATUS = "OFFLINE"
            WD_LAST_SEEN = None
            return {"alive": False, "last_seen": None, "status": "OFFLINE"}

        per_dev = {}
        any_ok = False
        any_stale = False
        max_delta = 0.0

        for mac in devices:
            entry = self._find(dump, mac)

            # Kein Eintrag im Dump → OFFLINE für dieses Gerät
            if not entry:
                per_dev[mac] = {
                    "alive": False,
                    "last_seen": None,
                    "status": "OFFLINE",
                }
                continue

            raw = entry.get("raw", "")

            last_raw = self._last_raw.get(mac)
            last_ts = self._last_ts.get(mac)
            stale_flag = self._stale_reported.get(mac, False)

            # --- erster Kontakt ---
            if last_raw is None:
                self._last_raw[mac] = raw
                self._last_ts[mac] = now
                self._stale_reported[mac] = False

                per_dev[mac] = {
                    "alive": True,
                    "last_seen": 0.0,
                    "status": "OK",
                }
                any_ok = True
                continue

            # --- neue Daten ---
            if raw != last_raw:
                self._last_raw[mac] = raw
                self._last_ts[mac] = now
                self._stale_reported[mac] = False

                per_dev[mac] = {
                    "alive": True,
                    "last_seen": 0.0,
                    "status": "OK",
                }
                any_ok = True
                continue

            # --- gleiche Daten ---
            delta = now - (last_ts or now)
            if delta > max_delta:
                max_delta = delta

            if delta < self.timeout:
                per_dev[mac] = {
                    "alive": True,
                    "last_seen": delta,
                    "status": "OK",
                }
                any_ok = True
            else:
                # STALE (ZOMBIE), NICHT OFFLINE
                self._stale_reported[mac] = True
                per_dev[mac] = {
                    "alive": False,
                    "last_seen": delta,
                    "status": "STALE",
                }
                any_stale = True

        # ----------------------------------------------------
        # Global-Aggregat (für Core / Decoder)
        # ----------------------------------------------------
        if any_ok:
            WD_ALIVE = True
            WD_STATUS = "OK"
            WD_LAST_SEEN = 0.0
        elif any_stale:
            WD_ALIVE = False
            WD_STATUS = "STALE"
            WD_LAST_SEEN = max_delta
        else:
            WD_ALIVE = False
            WD_STATUS = "OFFLINE"
            WD_LAST_SEEN = None

        # Rückgabe-Kompatibilität bleibt: alive/last_seen/status
        # + optional details, falls du später auswerten willst
        return {
            "alive": WD_ALIVE,
            "last_seen": WD_LAST_SEEN,
            "status": WD_STATUS,
            "devices": per_dev,
        }

    # --------------------------------------------------------
    # Thread-Loop
    # --------------------------------------------------------
    def start(self):
        import threading

        if self.running:
            return

        self.running = True

        def loop():
            while self.running:
                st = self.check_status()
                try:
                    self.callback(st)
                except Exception:
                    pass
                time.sleep(self.interval)

        threading.Thread(target=loop, daemon=True).start()

    def stop(self):
        self.running = False
