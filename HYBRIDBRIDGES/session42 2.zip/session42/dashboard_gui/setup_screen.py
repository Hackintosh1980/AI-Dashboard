# setup_screen.py – Session42 FIXED CLEAN

import os
import json
import time

from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.clock import Clock
from kivy.utils import platform

from dashboard_gui.ui.setup_content.setup_main_panel import SetupMainPanel
from dashboard_gui.ui.common.header_online import HeaderBar
import config

_last_seen = {}     # mac -> {raw, ts}
_selected = {}      # mac -> {"profile": str}


def _raw_path():
    if platform == "android":
        try:
            from jnius import autoclass
            ctx = autoclass("org.kivy.android.PythonActivity").mActivity
            return os.path.join(ctx.getFilesDir().getAbsolutePath(), "ble_dump.json")
        except:
            pass

    base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, "..", "data", "ble_dump.json")


def _status(mac, raw, timeout):
    now = time.time()
    old = _last_seen.get(mac)

    if not old:
        state = "living"
    else:
        unchanged = (old["raw"] == raw)
        if unchanged and now - old["ts"] >= timeout:
            state = "zombie"
        else:
            state = "living"

    _last_seen[mac] = {"raw": raw, "ts": now}
    return state


class SetupScreen(Screen):

    def __init__(self, **kw):
        super().__init__(**kw)

        # -------------------------------------------
        # 🔥 Richtige Registrierung beim GSM
        # -------------------------------------------
        from dashboard_gui.global_state_manager import GLOBAL_STATE
        GLOBAL_STATE.attach_setup(self)

        root = BoxLayout(orientation="vertical", spacing=10, padding=10)
        self.add_widget(root)

        self.header = HeaderBar(
            goto_setup=lambda *_: None,
            goto_debug=lambda *_: setattr(self.manager, "current", "debug"),
            goto_device_picker=lambda *_: setattr(self.manager, "current", "device_picker"),
        )
        self.header.lbl_title.text = "Setup"
        self.header.update_back_button("setup")
        root.add_widget(self.header)

        self.panel = SetupMainPanel(
            on_refresh=self.update_devices,
            on_save=self._save,
            on_back=self._back,
            on_profile_change=self._set_profile
        )
        root.add_widget(self.panel)

        Clock.schedule_once(self.update_devices, 0.3)

    # ---------------------------------------------------------
    def update_devices(self, *_):
        timeout = config.get_stale_timeout()
        self.panel.clear_devices()

        path = _raw_path()
        if not os.path.exists(path):
            print("[Setup] dump fehlt")
            return

        try:
            arr = json.load(open(path, "r"))
        except:
            print("[Setup] JSON Fehler")
            return

        for e in arr:
            mac = e.get("address")
            raw = e.get("raw")

            if not mac or not raw:
                continue

            st = _status(mac, raw, timeout)
            prof = _selected.get(mac, {}).get("profile", config.get_device_profile(mac))

            self.panel.add_device(mac, st, prof)

    # ---------------------------------------------------------
    def _set_profile(self, mac, prof):
        _selected[mac] = {"profile": prof}

    # ---------------------------------------------------------
    def _save(self, *_):

        if not _selected:
            print("[Setup] WARNUNG: Speichern abgebrochen – keine Geräte ausgewählt!")
            return

        cfg = config._init()
        devs = {mac: {"profile": d["profile"]} for mac, d in _selected.items()}

        cfg["devices"] = devs

        config.save(cfg)
        print("[Setup] gespeichert:", devs)

        self._back()

    # ---------------------------------------------------------
    def _back(self, *_):
        if self.manager:
            self.manager.current = "dashboard"

    # ---------------------------------------------------------
    # LIVE UPDATE FROM GSM (minimal – nur Header!)
    # ---------------------------------------------------------
    def update_from_global(self, d):
        """Setup-Screen: nur Header aktualisieren, keine Sensorlogik."""
        try:
            self.header.set_clock(time.strftime("%H:%M:%S"))
            self.header.set_rssi(d.get("rssi"))
            self.header.set_external(d.get("external", {}).get("present", False))
            self.header.set_device_label(d.get("device_id"))
        except Exception as e:
            print("[Setup] update_from_global error:", e)
