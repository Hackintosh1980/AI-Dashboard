# dashboard_gui/global_state_manager.py
# HEARTBEAT + MULTI-DEVICE – CLEAN VERSION

from kivy.clock import Clock
from dashboard_gui.data_buffer import BUFFER


def _extract_mac(dev):
    """Normiert device_id auf reine MAC."""
    if isinstance(dev, dict):
        return dev.get("device_id")
    return dev


class GlobalStateManager:
    def __init__(self):
        # Run-State
        self.running = True

        # Screen Refs
        self.dashboard_ref = None
        self.fullscreen_ref = None
        self.setup_ref = None
        
        # Aktives Gerät (Index)
        self.active_index = 0

        # LED Status
        self.led_state = {"alive": False, "status": "offline"}

        # Heartbeat
        self._last_counter = None

        # Global Tick
        Clock.schedule_interval(self._global_update, 0.5)

    # ---------------------------------------------------------
    # PUBLIC API – Device Switch
    # ---------------------------------------------------------

    def set_active_index(self, idx):
            idx = int(idx)
            if idx < 0:
                idx = 0
    
            self.active_index = idx
            self._last_counter = None
            print(f"[GSM] Active device -> {idx}")
    
            # Header sofort aktualisieren
            data = BUFFER.get()
            if isinstance(data, list) and len(data) > idx:
                mac = data[idx].get("device_id")
    
                if self.dashboard_ref:
                    self.dashboard_ref.header.set_device_label(mac)
                if self.fullscreen_ref:
                    self.fullscreen_ref.header.set_device_label(mac)
                if self.setup_ref:
                    self.setup_ref.header.set_device_label(mac)


    def get_device_list(self):
            data = BUFFER.get()
            if not data or not isinstance(data, list):
                return []
            return [d.get("device_id") for d in data]

    # ---------------------------------------------------------
    # Screen Attach
    # ---------------------------------------------------------
    def attach_dashboard(self, scr):
        self.dashboard_ref = scr

    def attach_fullscreen(self, scr):
        self.fullscreen_ref = scr

    def attach_setup(self, scr):
        self.setup_ref = scr

    # ---------------------------------------------------------
    # LED Helpers
    # ---------------------------------------------------------
    def _push_led(self):
        if self.dashboard_ref:
            self.dashboard_ref.header.set_led(self.led_state)
        if self.fullscreen_ref:
            self.fullscreen_ref.header.set_led(self.led_state)
        if self.setup_ref:
            self.setup_ref.header.set_led(self.led_state)

    def _led_offline(self):
        self.led_state = {"alive": False, "status": "offline"}
        self._push_led()

    def _led_nodata(self):
        self.led_state = {"alive": False, "status": "nodata"}
        self._push_led()

    def _led_stale(self):
        self.led_state = {"alive": True, "status": "stale"}
        self._push_led()

    def _led_flow(self):
        self.led_state = {"alive": True, "status": "flow"}
        self._push_led()

    # ---------------------------------------------------------
    # Drei-Gestirn
    # ---------------------------------------------------------
    def start(self):
        print("[STATE] START")
        self.running = True
        self._led_offline()
        self._refresh_all_buttons()

    def stop(self):
        print("[STATE] STOP")
        self.running = False
        self._led_offline()
        self._last_counter = None
        self._refresh_all_buttons()

    def reset(self):
        print("[STATE] RESET")
        self._led_offline()
        self._last_counter = None
        self._refresh_all_buttons()

        if self.dashboard_ref:
            self.dashboard_ref.reset_from_global()
        if self.fullscreen_ref:
            self.fullscreen_ref.reset_from_global()

    # ---------------------------------------------------------
    # GLOBAL TICK
    # ---------------------------------------------------------
    def _global_update(self, dt):
        BUFFER.soft_reload()
        data = BUFFER.get()

        if not self.running:
            return

        if not data or not isinstance(data, list):
            self._led_nodata()
            return

        # aktives Gerät sauber clampen
        idx = min(self.active_index, len(data)-1)
        d = data[idx]

        # MAC flatten
        mac = _extract_mac(d.get("device_id"))
        d["device_id"] = mac
        d["device_id_flat"] = mac

        # alive Handling
        alive = d.get("alive", False)
        if not alive:
            self._led_nodata()
        else:
            counter = d.get("packet_counter")
            if counter is None:
                self._led_stale()
            else:
                if self._last_counter is None:
                    self._led_stale()
                else:
                    if counter != self._last_counter:
                        self._led_flow()
                    else:
                        self._led_stale()
                self._last_counter = counter

        if not self.running:
            return

        # active key mapping
        d["_active_keys"] = self.extract_active_keys(d)

        # Dashboard updates
        if self.dashboard_ref:
            self.dashboard_ref.update_from_global(d)
        if self.fullscreen_ref:
            self.fullscreen_ref.update_from_global(d)

        if self.setup_ref:
            self.setup_ref.update_from_global(d)
    # ---------------------------------------------------------
    # Active Keys
    # ---------------------------------------------------------
    def extract_active_keys(self, d):
        active = []
        if d["internal"]["temperature"]["value"] is not None:
            active.append("temp_in")
        if d["internal"]["humidity"]["value"] is not None:
            active.append("hum_in")
        if d["vpd_internal"]["value"] is not None:
            active.append("vpd_in")

        if d["external"]["present"]:
            if d["external"]["temperature"]["value"] is not None:
                active.append("temp_ex")
            if d["external"]["humidity"]["value"] is not None:
                active.append("hum_ex")
            if d["vpd_external"]["value"] is not None:
                active.append("vpd_ex")

        return active

    # ---------------------------------------------------------
    # Button Sync
    # ---------------------------------------------------------
    def _refresh_all_buttons(self):
        if self.dashboard_ref and hasattr(self.dashboard_ref, "controls"):
            self.dashboard_ref.controls.refresh_state(self.running)
        if self.fullscreen_ref and hasattr(self.fullscreen_ref, "controls"):
            self.fullscreen_ref.controls.refresh_state(self.running)

    # ---------------------------------------------------------
    # APPLY NEW CONFIG – globaler Refresh
    # ---------------------------------------------------------
    def apply_new_config(self):
        import config
        import decoder
        from kivy.app import App

        print("[GSM] Neue Config wird angewendet…")

        # 1) Config reload
        try:
            if hasattr(config, "reload"):
                config.reload()
            else:
                config.load()
            print("[GSM] Config reloaded.")
        except Exception as e:
            print("[GSM] Fehler beim Config-Reload:", e)

        # 2) Decoder weicher Reset (keine Threads zerstören)
        try:
            if hasattr(decoder, "UPTIME_START"):
                decoder.UPTIME_START = None
            print("[GSM] Decoder soft-synced.")
        except Exception as e:
            print("[GSM] Decoder-Sync Fehler:", e)

        # 3) Screens refreshen (nur wenn vorgesehen)
        app = App.get_running_app()
        if not app:
            return

        sm = app.sm  # kommt aus deiner main.py

        for screen_name in [
            "dashboard",
            "fullscreen",
            "device_picker",
            "debug",
            "filemanager",
            "setup"
        ]:
            try:
                scr = sm.get_screen(screen_name)
                if hasattr(scr, "refresh_after_config"):
                    scr.refresh_after_config()
                    print(f"[GSM] {screen_name} refreshed.")
            except:
                pass

        print("[GSM] Config vollständig aktiviert.")

GLOBAL_STATE = GlobalStateManager()
