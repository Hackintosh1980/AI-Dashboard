#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import traceback

from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.metrics import dp
from kivy.utils import platform
from kivy.uix.screenmanager import Screen


# ------------------------------------------------------------
# Realpfade
# ------------------------------------------------------------
def get_real_app_paths():
    paths = {}

    if platform == "android":
        try:
            from jnius import autoclass
            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            ctx = PythonActivity.mActivity

            files = ctx.getFilesDir().getAbsolutePath()
            app_root = ctx.getFilesDir().getParentFile().getAbsolutePath()
            data_root = os.path.join(files, "app", "data")

            paths["platform"] = "Android"
            paths["files_dir"] = files
            paths["app_root"] = app_root
            paths["data_root"] = data_root

            paths["raw_dump"]  = os.path.join(files, "ble_dump.json")
            paths["decoded"]   = os.path.join(data_root, "decoded.json")
            paths["config"]    = os.path.join(data_root, "config.json")
            paths["profiles"]  = os.path.join(data_root, "decoder_profiles")

            return paths

        except Exception as e:
            paths["error"] = str(e)
            paths["platform"] = "Android"
            return paths

    base = os.path.dirname(os.path.abspath(__file__))
    app_root = os.path.abspath(os.path.join(base, ".."))
    data_root = os.path.join(app_root, "data")

    paths["platform"] = "Desktop"
    paths["files_dir"] = data_root
    paths["app_root"] = app_root
    paths["data_root"] = data_root

    paths["raw_dump"]  = os.path.join(data_root, "ble_dump.json")
    paths["decoded"]   = os.path.join(data_root, "decoded.json")
    paths["config"]    = os.path.join(data_root, "config.json")
    paths["profiles"]  = os.path.join(data_root, "decoder_profiles")

    return paths


# ------------------------------------------------------------
# Safe Read
# ------------------------------------------------------------
def safe_read(path, max_len=2500):
    if not os.path.exists(path):
        return "[Datei nicht gefunden]"
    try:
        with open(path, "r", encoding="utf-8") as f:
            txt = f.read(max_len)
        if len(txt) >= max_len:
            txt += "\n… (gekürzt)"
        return txt
    except Exception as e:
        return f"[Fehler beim Lesen: {e}]"


# ------------------------------------------------------------
# DEBUG SCREEN
# ------------------------------------------------------------
class DebugScreen(Screen):
    def __init__(self, **kw):
        super().__init__(**kw)

        root = BoxLayout(orientation="vertical")
        self.add_widget(root)

        scroll = ScrollView(size_hint=(1, 1))
        self.layout = BoxLayout(
            orientation="vertical",
            padding=dp(12),
            spacing=dp(12),
            size_hint_y=None,
        )
        self.layout.bind(minimum_height=self._set_min_height)
        scroll.add_widget(self.layout)
        root.add_widget(scroll)

        # ----------------------------------------------------
        # BUTTON-BAR: Refresh – FileManager – Back
        # ----------------------------------------------------
        btn_area = BoxLayout(size_hint=(1, None), height=dp(60), spacing=20)

        btn_refresh = Button(
            text="Refresh",
            on_release=lambda *_: self._build_content()
        )

        btn_file = Button(
            text="Dateien",
            on_release=lambda *_: setattr(self.manager, "current", "filemanager")
        )

        btn_back = Button(
            text="Zurück",
            on_release=lambda *_: self._go_back()
        )

        btn_area.add_widget(btn_refresh)
        btn_area.add_widget(btn_file)
        btn_area.add_widget(btn_back)

        root.add_widget(btn_area)

        self._build_content()


    # --------------------------------------------------------
    # Helpers
    # --------------------------------------------------------
    def _add_label(self, text, font_size, bold=False, color=(1, 1, 1, 1)):
        if bold:
            text = f"[b]{text}[/b]"
        lbl = Label(
            text=text,
            markup=True,
            font_size=font_size,
            color=color,
            halign="left",
            valign="top",
            size_hint_y=None,
        )
        lbl.bind(
            width=lambda inst, w: setattr(inst, "text_size", (w, None)),
            texture_size=lambda inst, ts: setattr(inst, "height", ts[1]),
        )
        self.layout.add_widget(lbl)
        return lbl

    def _add_separator(self):
        self._add_label("─" * 40, dp(10), color=(0.6, 0.6, 0.6, 1))

    def _set_min_height(self, instance, value):
        self.layout.height = value


    # --------------------------------------------------------
    # Content Builder
    # --------------------------------------------------------
    def _build_content(self):
        self.layout.clear_widgets()

        try:
            paths = get_real_app_paths()

            self._add_label("REAL DEBUG – echte Systempfade", dp(20), bold=True)
            self._add_label(f"Plattform: {paths.get('platform')}", dp(14))

            # Fehler anzeigen
            if "error" in paths:
                self._add_label(f"Pfad-Fehler: {paths['error']}", dp(12), color=(1, 0.4, 0.4, 1))
                self._add_separator()

            # SYSTEMPFAD-SEKTION
            self._add_separator()
            self._add_label("Systempfad-Übersicht", dp(18), bold=True)

            for key in ["app_root", "files_dir", "data_root", "raw_dump", "decoded", "config", "profiles"]:
                if key in paths:
                    self._add_label(f"[b]{key}[/b]\n{paths[key]}", dp(12))

            # RAW-DUMP
            self._add_separator()
            self._add_label("ble_dump.json (RAW)", dp(18), bold=True)

            raw = paths.get("raw_dump")
            if raw and os.path.exists(raw):
                self._add_label("✓ Datei existiert", dp(12), color=(0.3, 1, 0.3, 1))
                self._add_label(f"[code]{safe_read(raw)}[/code]", dp(11))
            else:
                self._add_label("✗ Datei fehlt", dp(12), color=(1, 0.4, 0.4, 1))

            # DECODED – SUCHE AN ALLEN ORTEN
            self._add_separator()
            self._add_label("decoded.json – Pfadsuche", dp(18), bold=True)

            possible = [
                paths.get("decoded"),
                os.path.join(paths.get("files_dir", ""), "decoded.json"),
                os.path.join(paths.get("files_dir", ""), "app", "data", "decoded.json"),
                os.path.join(paths.get("data_root", ""), "decoded.json"),
            ]

            seen = set()
            for p in possible:
                if not p or p in seen:
                    continue
                seen.add(p)
                if os.path.exists(p):
                    self._add_label(f"✓ {p}", dp(12), color=(0.3, 1, 0.3, 1))
                    self._add_label(f"[code]{safe_read(p)}[/code]", dp(11))
                else:
                    self._add_label(f"✗ {p}", dp(12), color=(1, 0.4, 0.4, 1))

            # CONFIG
            self._add_separator()
            self._add_label("config.json", dp(18), bold=True)

            cfg = paths.get("config")
            if cfg and os.path.exists(cfg):
                self._add_label("✓ Datei existiert", dp(12), color=(0.3, 1, 0.3, 1))
                self._add_label(f"[code]{safe_read(cfg)}[/code]", dp(11))
            else:
                self._add_label("✗ Datei fehlt", dp(12), color=(1, 0.4, 0.4, 1))

            # PROFILE
            self._add_separator()
            self._add_label("Decoder-Profile", dp(18), bold=True)
            prof_dir = paths.get("profiles")

            if prof_dir and os.path.exists(prof_dir):
                files = sorted(os.listdir(prof_dir))
                self._add_label(f"✓ {len(files)} Dateien", dp(12), color=(0.3, 1, 0.3, 1))

                for f in files:
                    fp = os.path.join(prof_dir, f)
                    self._add_label(f"{f}", dp(13), bold=True)
                    self._add_label(f"[code]{safe_read(fp)}[/code]", dp(11))
            else:
                self._add_label("✗ Kein Profilordner", dp(12), color=(1, 0.4, 0.4, 1))

        except Exception:
            self._add_label("[Fehler beim Aufbau]", dp(16), color=(1, 0.4, 0.4, 1), bold=True)
            self._add_label(traceback.format_exc(), dp(11), color=(1, 0.6, 0.6, 1))


    # --------------------------------------------------------
    # Navigation
    # --------------------------------------------------------
    def _go_back(self):
        if self.manager:
            self.manager.current = "dashboard"
