# csv_viewer_table.py – Dark-Pro Tabelle (2D scroll, sticky header)

import os
import csv

from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label

from dashboard_gui.ui.scaling_utils import dp_scaled, sp_scaled


class CSVTableView(BoxLayout):
    """
    Dark-Pro CSV Tabellenansicht:
    - Sticky Header
    - 2D Scroll (horizontal + vertikal)
    - Dark-Pro Farben
    - Auto-Spaltenbreiten
    """

    def __init__(self, **kw):
        super().__init__(**kw)

        self.orientation = "vertical"
        self.csv_path = None

        # -----------------------------------------------
        # HEADER-Bereich (sticky)
        # -----------------------------------------------
        self.header_row = GridLayout(
            cols=1,
            size_hint_y=None,
            height=dp_scaled(32),
            padding=[dp_scaled(4), 0],
        )
        self.add_widget(self.header_row)

        # -----------------------------------------------
        # 2D SCROLLBEREICH: HORIZONTAL + VERTIKAL
        # -----------------------------------------------
        self.outer_scroll = ScrollView(
            size_hint=(1, 1),
            bar_width=dp_scaled(6),
            scroll_type=['content'],   # horizontale scroll
            do_scroll_y=False,
            do_scroll_x=True,
        )

        # innerer Scroll für vertikalen Scroll
        self.inner_scroll = ScrollView(
            size_hint=(None, 1),
            bar_width=dp_scaled(6),
            do_scroll_x=False,
            do_scroll_y=True,
        )

        # Inhalt der Tabelle
        self.table_grid = GridLayout(
            cols=1,
            size_hint_y=None,
            spacing=dp_scaled(2),
            padding=[dp_scaled(2), dp_scaled(2)],
        )
        self.table_grid.bind(minimum_height=lambda inst, h: setattr(inst, "height", h))

        self.inner_scroll.add_widget(self.table_grid)
        self.outer_scroll.add_widget(self.inner_scroll)
        self.add_widget(self.outer_scroll)

    # -----------------------------------------------
    # CSV LADEN
    # -----------------------------------------------
    def set_csv_path(self, p):
        self.csv_path = p
        self.reload()

    # -----------------------------------------------
    # CSV neu einlesen & Tabelle aufbauen
    # -----------------------------------------------
    def reload(self):
        if not self.csv_path or not os.path.exists(self.csv_path):
            self._show_error(f"File not found:\n{self.csv_path}")
            return

        try:
            with open(self.csv_path, "r", encoding="utf-8") as f:
                reader = csv.reader(f)
                rows = list(reader)
        except Exception as e:
            self._show_error(f"CSV lesen fehlgeschlagen:\n{e}")
            return

        if not rows:
            self._show_error("Keine Daten im CSV.")
            return

        header = rows[0]
        body = rows[1:]

        # Struktur neu bauen
        self.header_row.clear_widgets()
        self.table_grid.clear_widgets()

        # -----------------------------------------------
        # HEADER (sticky)
        # -----------------------------------------------
        header_layout = GridLayout(
            cols=len(header),
            size_hint_y=None,
            height=dp_scaled(32),
            padding=[dp_scaled(4), dp_scaled(4)],
        )

        for h in header:
            lbl = Label(
                text=h,
                size_hint_y=None,
                height=dp_scaled(32),
                font_size=sp_scaled(14),
                color=(0.95, 0.95, 0.98, 1),
                bold=True,
                halign="left",
                valign="middle",
            )
            lbl.bind(size=lambda inst, *_: inst.texture_update())
            header_layout.add_widget(lbl)

        self.header_row.add_widget(header_layout)

        # -----------------------------------------------
        # BODY (zeilenweise)
        # -----------------------------------------------
        for idx, row in enumerate(body):
            bg_color = (0.12, 0.12, 0.18, 1) if idx % 2 == 0 else (0.10, 0.10, 0.15, 1)

            line_layout = GridLayout(
                cols=len(header),
                size_hint_y=None,
                height=dp_scaled(28),
                padding=[dp_scaled(4), 0],
            )

            for cell in row:
                lbl = Label(
                    text=cell,
                    size_hint_y=None,
                    height=dp_scaled(28),
                    font_size=sp_scaled(13),
                    color=(0.90, 0.90, 0.95, 1),
                    halign="left",
                    valign="middle",
                )
                lbl.bind(size=lambda inst, *_: inst.texture_update())
                line_layout.add_widget(lbl)

            # Hintergrundfarbe auf GridLayout anwenden
            with line_layout.canvas.before:
                from kivy.graphics import Color, Rectangle
                Color(*bg_color)
                rect = Rectangle(pos=line_layout.pos, size=line_layout.size)
                line_layout.bind(
                    pos=lambda inst, *_: setattr(rect, "pos", inst.pos),
                    size=lambda inst, *_: setattr(rect, "size", inst.size),
                )

            self.table_grid.add_widget(line_layout)

        # Breite der inner_scroll an die Breite der Tabelle koppeln
        header_width = header_layout.width
        self.inner_scroll.width = max(dp_scaled(300), header_layout.width)

    # -----------------------------------------------
    # Fehler anzeigen
    # -----------------------------------------------
    def _show_error(self, msg):
        self.header_row.clear_widgets()
        self.table_grid.clear_widgets()

        lbl = Label(
            text=msg,
            font_size=sp_scaled(14),
            color=(1, 0.6, 0.6, 1),
            halign="left",
            valign="top",
        )
        lbl.bind(size=lambda inst, *_: inst.texture_update())
        self.table_grid.add_widget(lbl)
