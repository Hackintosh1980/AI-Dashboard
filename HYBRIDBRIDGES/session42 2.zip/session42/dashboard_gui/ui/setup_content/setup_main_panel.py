# setup_main_panel.py – Dark Mode + klare Auswahl + Header-kompatibel

from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner
from kivy.metrics import dp
from kivy.graphics import Color, Rectangle
from kivy.uix.scrollview import ScrollView
import os, json

def list_profiles():
    base = os.path.join(os.path.dirname(__file__), "..", "..", "..", "data", "decoder_profiles")
    names = []
    for f in os.listdir(base):
        if f.endswith(".json"):
            names.append(f.replace(".json", ""))  # Datei → Profilname
    return sorted(names)

class SetupMainPanel(BoxLayout):

    def __init__(self, on_refresh, on_save, on_back, on_profile_change, **kw):
        super().__init__(orientation="vertical", spacing=15, **kw)

        self.on_refresh = on_refresh
        self.on_save = on_save
        self.on_back = on_back
        self.on_profile_change = on_profile_change

        # Dark background
        with self.canvas.before:
            Color(0.08, 0.08, 0.08, 1)
            self.bg = Rectangle()

        self.bind(size=self._update_bg, pos=self._update_bg)

        # Scrollable device list
        scroll = ScrollView(size_hint=(1, 1))
        self.device_box = BoxLayout(
            orientation="vertical",
            spacing=8,
            padding=[5, 5, 5, 5],
            size_hint_y=None
        )
        self.device_box.bind(minimum_height=self.device_box.setter("height"))
        scroll.add_widget(self.device_box)
        self.add_widget(scroll)

        # Bottom buttons
        btns = BoxLayout(size_hint_y=None, height=dp(55), spacing=15)

        btns.add_widget(Button(text="↻ Refresh", background_color=(0.2,0.2,0.2,1)))
        btns.children[0].bind(on_release=lambda *_: self.on_refresh())

        btns.add_widget(Button(text="💾 Save", background_color=(0.2,0.5,0.2,1)))
        btns.children[0].bind(on_release=lambda *_: self.on_save())

        btns.add_widget(Button(text="← Back", background_color=(0.5,0.2,0.2,1)))
        btns.children[0].bind(on_release=lambda *_: self.on_back())

        self.add_widget(btns)

    def _update_bg(self, *_):
        self.bg.size = self.size
        self.bg.pos = self.pos

    # -----------------------------------------------------
    def clear_devices(self):
        self.device_box.clear_widgets()

    # -----------------------------------------------------
    def add_device(self, mac, status, profile):
        # row
        row = BoxLayout(
            orientation="horizontal",
            size_hint_y=None,
            height=dp(48),
            spacing=10,
            padding=[5,5,5,5]
        )

        # COLOR BASED ON STATUS
        if status == "living":
            col = (0.3, 1.0, 0.3, 1)   # green
        else:
            col = (1.0, 0.5, 0.2, 1)   # orange

        mac_label = Label(
            text=f"{mac}  ({status})",
            size_hint_x=0.6,
            halign="left",
            valign="middle",
            color=col,
            font_size=dp(18)
        )
        mac_label.bind(size=lambda inst, val: setattr(inst, "text_size", inst.size))
        row.add_widget(mac_label)

        # PROFILE DROPDOWN
        spinner = Spinner(
            text=profile,
            values=list_profiles(),
            size_hint_x=0.4,
            background_color=(0.15,0.15,0.15,1),
            color=(1,1,1,1),
            font_size=dp(18)
        )

        spinner.bind(text=lambda inst, val: self.on_profile_change(mac, val))

        row.add_widget(spinner)

        self.device_box.add_widget(row)
