import os
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy_garden.graph import Graph, LinePlot
from kivy.uix.behaviors import ButtonBehavior
from kivy.graphics import Rectangle, Color

from dashboard_gui.ui.scaling_utils import dp_scaled, sp_scaled


class ChartTile(ButtonBehavior, BoxLayout):

    def __init__(self, title, unit, color_rgba, bg=None, **kw):
        ButtonBehavior.__init__(self)
        BoxLayout.__init__(
            self,
            orientation="vertical",
            spacing=dp_scaled(6),
            padding=dp_scaled(6),
            **kw
        )

        self.title = title
        self.unit = unit
        self.color = color_rgba
        self.window = 60
        self.buffer = []
        self.last_value = None
        self.smoothing = 0.25

        # -------------------------------------------------
        # BACKGROUND
        # -------------------------------------------------
        if bg:
            self.bg_path = os.path.join("dashboard_gui", "assets", "tiles", bg)
        else:
            self.bg_path = None

        with self.canvas.before:
            if self.bg_path:
                self.bg_rect = Rectangle(source=self.bg_path, pos=self.pos, size=self.size)
            else:
                Color(0, 0, 0, 0)
                self.bg_rect = Rectangle(pos=self.pos, size=self.size)

        self.bind(pos=self._upd_bg, size=self._upd_bg)

        # -------------------------------------------------
        # HEADER (TITLE • TREND • VALUE)
        # -------------------------------------------------
        header = BoxLayout(
            orientation="horizontal",
            size_hint_y=None,
            height=dp_scaled(38),
            spacing=dp_scaled(4),
        )

        self.lbl_title = Label(text=title, font_size=sp_scaled(16))
        self.lbl_trend = Label(text="", font_size=sp_scaled(18), font_name="FA")
        self.lbl_value = Label(text="--", font_size=sp_scaled(18))

        header.add_widget(self.lbl_title)
        header.add_widget(self.lbl_trend)
        header.add_widget(self.lbl_value)
        self.add_widget(header)

        # -------------------------------------------------
        # GRAPH
        # -------------------------------------------------
        self.graph = Graph(
            xlabel="", ylabel="",
            x_ticks_major=0, x_ticks_minor=0,
            y_ticks_major=0, y_ticks_minor=0,
            x_grid_label=False, y_grid_label=False,
            draw_border=False,
            padding=dp_scaled(4),
            xmin=0, xmax=self.window,
            ymin=0, ymax=1,
            background_color=(0, 0, 0, 0),
            tick_color=(0, 0, 0, 0),
            size_hint=(1, 1),
        )

        self.plot = LinePlot(color=self.color, line_width=2.0)
        self.graph.add_plot(self.plot)

        glow = [self.color[0], self.color[1], self.color[2], 0.25]
        self.plot_glow = LinePlot(color=glow, line_width=5.0)
        self.graph.add_plot(self.plot_glow)

        self.add_widget(self.graph)

        # -------------------------------------------------
        # FOOTER
        # -------------------------------------------------
        footer = BoxLayout(
            orientation="horizontal",
            size_hint_y=None,
            height=dp_scaled(22),
            spacing=dp_scaled(4),
        )

        self.lbl_avg = Label(text="avg: --", font_size=sp_scaled(12))
        self.lbl_minmax = Label(text="", font_size=sp_scaled(12))

        footer.add_widget(self.lbl_avg)
        footer.add_widget(self.lbl_minmax)

        self.add_widget(footer)


    # -------------------------------------------------
    # BACKGROUND UPDATE
    # -------------------------------------------------
    def _upd_bg(self, *_):
        self.bg_rect.pos = self.pos
        self.bg_rect.size = self.size

    # -------------------------------------------------
    # UPDATE
    # -------------------------------------------------
    def update(self, value):
        if value is None:
            return

        try:
            v = float(value)
        except:
            return

        if self.last_value is None:
            smoothed = v
        else:
            smoothed = (self.last_value * (1 - self.smoothing)) + (v * self.smoothing)

        self.last_value = smoothed
        self.lbl_value.text = f"{smoothed:.2f} {self.unit}"

        # Trend (neutral, keine Bewertung)
        if len(self.buffer) > 1:
            diff = smoothed - self.buffer[-1]
        
            if diff > 0.01:
                self.lbl_trend.text = "\uf062"      # ↑
            elif diff < -0.01:
                self.lbl_trend.text = "\uf063"      # ↓
            else:
                self.lbl_trend.text = "\uf061"      # →
        
            # immer NEUTRALE Farbe
            self.lbl_trend.color = (0.7, 0.7, 0.7, 1)
            
        # Buffer push
        self.buffer.append(smoothed)
        if len(self.buffer) > self.window:
            self.buffer.pop(0)

        # Graph update
        pts = [(i, val) for i, val in enumerate(self.buffer)]
        self.plot.points = pts
        self.plot_glow.points = pts

        # Y autoscale
        if len(self.buffer) > 1:
            mn = min(self.buffer)
            mx = max(self.buffer)
            if mn == mx:
                mn -= 0.5
                mx += 0.5

            margin = (mx - mn) * 0.2
            self.graph.ymin = mn - margin
            self.graph.ymax = mx + margin

        self.graph.xmax = max(self.window, len(self.buffer))

        # Footer
        if len(self.buffer) > 1:
            avg_v = sum(self.buffer) / len(self.buffer)
            self.lbl_avg.text = f"avg: {avg_v:.2f}"
            self.lbl_minmax.text = f"min: {mn:.2f}  max: {mx:.2f}"


    # -------------------------------------------------
    # RESET
    # -------------------------------------------------
    def reset(self):
        self.lbl_value.text = "--"
        self.lbl_trend.text = ""
        self.lbl_avg.text = "avg: --"
        self.lbl_minmax.text = ""

        self.buffer = []
        self.last_value = None
        self.plot.points = []
        self.plot_glow.points = []
        self.graph.ymin = 0
        self.graph.ymax = 1

    # -------------------------------------------------
    # TILE CLICK → FULLSCREEN
    # -------------------------------------------------
    def on_release(self, *_):
        parent = self.parent
        sm = None
        while parent:
            if hasattr(parent, "current") and hasattr(parent, "get_screen"):
                sm = parent
                break
            parent = parent.parent

        if sm is None:
            print("❌ ERROR: Kein ScreenManager gefunden!")
            return

        if not sm.has_screen("fullscreen"):
            print("❌ ERROR: Fullscreen existiert nicht!")
            return

        dashboard = sm.get_screen("dashboard")
        for key, tile in dashboard.content.tile_map.items():
            if tile is self:
                fs = sm.get_screen("fullscreen")
                fs.activate_tile(key)
                sm.current = "fullscreen"
                return

        print("❌ ERROR: Tile-Key nicht gefunden!")
