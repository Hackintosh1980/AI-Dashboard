# dashboard_gui/ui/cam_viewer_content/cam_viewer_screen.py

from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout

from dashboard_gui.ui.common.header_online import HeaderBar
from dashboard_gui.ui.cam_viewer_content.cam_viewer_panel import CamViewerPanel


class CamViewerScreen(Screen):
    """
    Voll integrierter Screen
    """

    def __init__(self, **kw):
        super().__init__(**kw)

        root = BoxLayout(orientation="vertical")

        # HEADER
        header = HeaderBar(
            goto_setup=lambda: setattr(self.manager, "current", "setup"),
            goto_debug=lambda: setattr(self.manager, "current", "debug"),
            goto_device_picker=lambda: setattr(self.manager, "current", "device_picker"),
        )
        header.update_back_button("cam_viewer")

        root.add_widget(header)

        # PANEL
        panel = CamViewerPanel()
        root.add_widget(panel)

        self.add_widget(root)
