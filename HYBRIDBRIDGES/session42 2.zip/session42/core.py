# core.py – FINAL (stabil)
# © 2025 Dominik Rosenthal

import os
from kivy.utils import platform as kivy_platform

import config
from bridge_manager import get_bridge
from watchdog_manager import DumpWatchdog
from decoder import start_decoder_thread, update_bridge_state

# ------------------------------------------------------------
# 🔥 100 % zuverlässige Android-Erkennung
# ------------------------------------------------------------
def is_android():
    if "ANDROID_ROOT" in os.environ:
        return True
    return kivy_platform == "android"


# globale Instanzen
_bridge = None
_watchdog = None


# ------------------------------------------------------------
# Watchdog Callback
# ------------------------------------------------------------
def _wd_callback(status):
    print(f"[Core] Watchdog: {status['status']} | alive={status['alive']} | last_seen={status['last_seen']}")

    update_bridge_state(
        alive=status["alive"],
        status=status["status"],
        last_seen=status["last_seen"]
    )


# ------------------------------------------------------------
# decoded.json löschen
# ------------------------------------------------------------
def _cleanup_decoded():
    base = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(base, "data", "decoded.json")
    try:
        if os.path.exists(path):
            os.remove(path)
            print("[Core] decoded.json entfernt")
    except:
        pass

def _cleanup_ble_dump():
    # Android/desktop – gleicher Pfad wie Watchdog
    from watchdog_manager import RAW_PATH

    try:
        if os.path.exists(RAW_PATH):
            os.remove(RAW_PATH)
            print("[Core] ble_dump.json entfernt")
    except:
        pass
# ------------------------------------------------------------
# START – von main.py
# ------------------------------------------------------------
def start():
    global _bridge, _watchdog

    print("[Core] Starte Core…")
    print("[Core] is_android():", is_android())

    _cleanup_decoded()
    _cleanup_ble_dump()
    # -----------------------------------------------------
    # Bridge starten
    # -----------------------------------------------------
    if is_android():
        try:
            from permission_fix import check_permissions
            check_permissions()
        except:
            print("[Core] Permission check skipped")

        _bridge = get_bridge(prefer_mock=False)
        _bridge.start()
        print("[Core] Android-Bridge gestartet")

    else:
        print("[Core] Desktop Mode – externe blebridge_desktop benutzen")
        _bridge = None

    # -----------------------------------------------------
    # Decoder starten (liefert decoded.json)
    # -----------------------------------------------------
    start_decoder_thread(config.get_refresh_interval())
    print("[Core] Decoder-Thread gestartet")

    # -----------------------------------------------------
    # Watchdog starten
    # -----------------------------------------------------
    _watchdog = DumpWatchdog(
        timeout=config.get_stale_timeout(),
        interval=config.get_refresh_interval(),
        callback=_wd_callback
    )
    _watchdog.start()
    print("[Core] Watchdog gestartet")

    print("[Core] System läuft.")


# ------------------------------------------------------------
# STOP
# ------------------------------------------------------------
def stop():
    global _bridge, _watchdog

    print("[Core] Stoppe System…")

    try:
        if _watchdog:
            _watchdog.stop()
            print("[Core] Watchdog gestoppt")
    except:
        pass

    try:
        if is_android() and _bridge:
            _bridge.stop()
            print("[Core] Bridge gestoppt")
    except:
        pass

    print("[Core] Shutdown abgeschlossen.")
