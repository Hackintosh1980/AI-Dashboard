package org.hackintosh1980.blebridge;

import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Context;
import android.util.Log;
import android.util.SparseArray;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

public class BleBridgePersistent {

    private static final String TAG = "HybridBridge";
    private static final long WRITE_INTERVAL_MS = 1200L;
    private static final int COMPANY_ID = 0x0019;

    // GATT ThermoPro TP351S
    private static final UUID TP_SERVICE =
            UUID.fromString("00010203-0405-0607-0809-0a0b0c0d1910");
    private static final UUID TP_CHAR =
            UUID.fromString("00010203-0405-0607-0809-0a0b0c0d2b10");

    private static volatile boolean running = false;

    // ADV
    private static BluetoothLeScanner scanner;
    private static ScanCallback advCallback;

    // GATT
    private static BluetoothGatt gatt;
    private static BluetoothDevice gattDevice;

    private static int gattCounter = 0;

    private static File outFile;
    private static final Object lock = new Object();
    private static final Map<String, JSONObject> lastPackets = new HashMap<>();

    private static String ts() {
        return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ",
                Locale.US).format(new Date());
    }

    // -----------------------------------------------------------------------
    // START
    // -----------------------------------------------------------------------
    public static String start(Context ctx, String outName) {
        if (running) return "ALREADY";
        running = true;

        outFile = new File(ctx.getFilesDir(), outName);

        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null || !adapter.isEnabled()) return "BT_OFF";

        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) return "NO_SCANNER";

        Log.i(TAG, "Hybrid Bridge starting…");

        // -------------------------------------------------------------------
        // ADV CALLBACK
        // -------------------------------------------------------------------
        advCallback = new ScanCallback() {
            @Override
            public void onScanResult(int type, ScanResult r) {
                try {
                    BluetoothDevice d = r.getDevice();
                    if (d == null) return;

                    ScanRecord rec = r.getScanRecord();
                    if (rec == null) return;

                    SparseArray<byte[]> md = rec.getManufacturerSpecificData();
                    if (md == null || md.size() == 0) return;

                    byte[] payload = md.get(COMPANY_ID);
                    if (payload == null && md.size() > 0)
                        payload = md.valueAt(0);

                    if (payload == null) return;

                    StringBuilder sb = new StringBuilder();
                    for (byte b : payload)
                        sb.append(String.format("%02X", b));

                    JSONObject obj = new JSONObject();
                    obj.put("timestamp", ts());
                    obj.put("name", d.getName() != null ? d.getName() : "(adv)");
                    obj.put("address", d.getAddress());
                    obj.put("rssi", r.getRssi());
                    obj.put("raw", sb.toString());
                    obj.put("note", "adv");

                    synchronized (lock) {
                        lastPackets.put(d.getAddress(), obj);
                    }

                    // Auto-connect GATT only if name matches ThermoPro
                    if (d.getName() != null &&
                            (d.getName().contains("TP351") || d.getName().contains("Thermo"))) {

                        if (gatt == null) {
                            Log.i(TAG, "Connecting GATT to " + d.getName());
                            gattDevice = d;
                            gatt = d.connectGatt(ctx, false, gattCallback);
                        }
                    }

                } catch (Throwable t) {
                    Log.e(TAG, "adv", t);
                }
            }
        };

        scanner.startScan(advCallback);

        // -------------------------------------------------------------------
        // WRITER THREAD
        // -------------------------------------------------------------------
        new Thread(() -> {
            while (running) {
                try {
                    JSONArray arr;

                    synchronized (lock) {
                        arr = new JSONArray(lastPackets.values());
                    }

                    File tmp = new File(outFile.getAbsolutePath() + ".tmp");

                    try (FileOutputStream fos = new FileOutputStream(tmp, false)) {
                        fos.write(arr.toString(2).getBytes());
                    }

                    tmp.renameTo(outFile);
                    Thread.sleep(WRITE_INTERVAL_MS);

                } catch (Throwable t) {
                    Log.e(TAG, "writer", t);
                }
            }
        }, "HybridWriter").start();

        return "OK";
    }

    // -----------------------------------------------------------------------
    // STOP
    // -----------------------------------------------------------------------
    public static void stop() {
        running = false;

        try {
            if (scanner != null && advCallback != null)
                scanner.stopScan(advCallback);
        } catch (Throwable ignored) {}

        try {
            if (gatt != null) {
                gatt.close();
                gatt = null;
            }
        } catch (Throwable ignored) {}

        Log.i(TAG, "Hybrid stopped");
    }

    // -----------------------------------------------------------------------
    // GATT CALLBACK
    // -----------------------------------------------------------------------
    private static final BluetoothGattCallback gattCallback =
            new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                Log.i(TAG, "GATT connected → discover services");
                g.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                Log.i(TAG, "GATT disconnected");
                gatt = null;
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            BluetoothGattService s = g.getService(TP_SERVICE);
            if (s == null) return;

            BluetoothGattCharacteristic c = s.getCharacteristic(TP_CHAR);
            if (c == null) return;

            g.setCharacteristicNotification(c, true);

            BluetoothGattDescriptor d = c.getDescriptor(
                    UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
            if (d != null) {
                d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                g.writeDescriptor(d);
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g,
                                            BluetoothGattCharacteristic ch) {

            byte[] v = ch.getValue();
            if (v == null) return;

            // Convert to hex
            StringBuilder sb = new StringBuilder();
            for (byte b : v)
                sb.append(String.format("%02X", b));

            // add counter prefix: 2 bytes hex
            gattCounter = (gattCounter + 1) & 0xFFFF;
            String counterHex = String.format("%04X", gattCounter);
            String hybridRaw = counterHex + sb.toString();

            try {
                JSONObject obj = new JSONObject();
                obj.put("timestamp", ts());
                obj.put("name", gattDevice != null ? gattDevice.getName() : "ThermoPro");
                obj.put("address", gattDevice != null ? gattDevice.getAddress() : "?");
                obj.put("rssi", 0);
                obj.put("raw", hybridRaw);
                obj.put("note", "gatt");

                synchronized (lock) {
                    lastPackets.put(obj.getString("address"), obj);
                }

            } catch (Throwable ignored) {}
        }
    };
}
