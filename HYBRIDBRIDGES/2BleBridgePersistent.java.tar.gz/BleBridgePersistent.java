package org.hackintosh1980.blebridge;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.util.Log;
import android.util.SparseArray;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * BleBridgePersistent – Android RAW → ble_dump.json
 * Drop-in Bridge für dein bestehendes Core/Watchdog-Setup.
 *
 * © 2025 Dominik Rosenthal
 */
public class BleBridgePersistent {

    private static final String TAG = "BleBridgePersistent";

    // VIVOSUN / Sensoren: Standard-Manufacturer-ID (du hattest 0x0019)
    private static final int COMPANY_ID = 0x0019;

    // Schreibrhythmus für ble_dump.json (ms)
    private static final long WRITE_INTERVAL_MS = 1500L;

    // Lauf- und Scan-Status
    private static volatile boolean running = false;
    private static BluetoothLeScanner scanner = null;
    private static ScanCallback callback = null;

    // Zieldatei
    private static File outFile = null;

    // Speicher für letzte Pakete pro MAC
    private static final Object lock = new Object();
    private static final Map<String, JSONObject> last = new HashMap<String, JSONObject>();

    // ISO-Timestamp wie im Desktop-Bridge
    private static String ts() {
        SimpleDateFormat fmt =
                new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US);
        return fmt.format(new Date());
    }

    /**
     * Startet die Bridge.
     *
     * @param ctx     Android Context (kommt wie gehabt aus Python/pyjnius)
     * @param outName Dateiname, z. B. "ble_dump.json"
     * @return "OK", "ALREADY", "BT_OFF", "NO_SCANNER" oder "ERR:…"
     */
    public static String start(Context ctx, String outName) {
        try {
            if (running) {
                Log.i(TAG, "already running");
                return "ALREADY";
            }

            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null || !adapter.isEnabled()) {
                Log.w(TAG, "Bluetooth off");
                return "BT_OFF";
            }

            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) {
                Log.e(TAG, "No BLE scanner");
                return "NO_SCANNER";
            }

            // ble_dump.json im App-internen Files-Verzeichnis
            outFile = new File(ctx.getFilesDir(), outName);
            Log.i(TAG, "→ writing to " + outFile.getAbsolutePath());

            running = true;

            // ScanCallback wie in deiner alten Persistent-Bridge
            callback = new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {
                    try {
                        BluetoothDevice dev = result.getDevice();
                        if (dev == null) return;

                        ScanRecord rec = result.getScanRecord();
                        if (rec == null) return;

                        SparseArray<byte[]> md = rec.getManufacturerSpecificData();
                        if (md == null || md.size() == 0) return;

                        // Versuche zuerst COMPANY_ID, sonst ersten Eintrag nehmen
                        byte[] payload = md.get(COMPANY_ID);
                        if (payload == null && md.size() > 0) {
                            payload = md.valueAt(0);
                        }
                        if (payload == null) return;

                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < payload.length; i++) {
                            sb.append(String.format(Locale.US, "%02X", payload[i]));
                        }

                        JSONObject obj = new JSONObject();
                        obj.put("timestamp", ts());
                        obj.put("name", dev.getName() != null ? dev.getName() : "(unknown)");
                        obj.put("address", dev.getAddress());
                        obj.put("rssi", result.getRssi());
                        obj.put("raw", sb.toString());
                        obj.put("note", "android raw dump");

                        synchronized (lock) {
                            last.put(dev.getAddress(), obj);
                        }
                    } catch (Throwable t) {
                        Log.e(TAG, "onScanResult", t);
                    }
                }

                @Override
                public void onBatchScanResults(java.util.List<ScanResult> results) {
                    if (results == null) return;
                    for (int i = 0; i < results.size(); i++) {
                        onScanResult(ScanSettings.CALLBACK_TYPE_ALL_MATCHES, results.get(i));
                    }
                }

                @Override
                public void onScanFailed(int errorCode) {
                    Log.e(TAG, "Scan failed: " + errorCode);
                }
            };

            scanner.startScan(callback);

            // Writer-Thread → schreibt periodisch ble_dump.json
            Thread writer = new Thread(new Runnable() {
                @Override
                public void run() {
                    while (running) {
                        try {
                            JSONArray arr;
                            synchronized (lock) {
                                arr = new JSONArray();
                                for (JSONObject obj : last.values()) {
                                    arr.put(obj);
                                }
                            }

                            File tmp = new File(outFile.getAbsolutePath() + ".tmp");
                            FileOutputStream fos = null;
                            try {
                                fos = new FileOutputStream(tmp, false);
                                fos.write(arr.toString(2).getBytes("UTF-8"));
                                fos.flush();
                            } finally {
                                if (fos != null) {
                                    try {
                                        fos.close();
                                    } catch (Exception ignore) {
                                    }
                                }
                            }
                            // Atomarer Swap
                            boolean renamed = tmp.renameTo(outFile);
                            if (!renamed) {
                                Log.w(TAG, "renameTo failed for " + tmp.getAbsolutePath());
                            }

                            Thread.sleep(WRITE_INTERVAL_MS);
                        } catch (Throwable t) {
                            Log.e(TAG, "writer", t);
                        }
                    }
                    Log.i(TAG, "writer thread done");
                }
            }, "BleBridgeWriter");

            writer.setDaemon(true);
            writer.start();

            return "OK";
        } catch (Throwable t) {
            Log.e(TAG, "start", t);
            return "ERR:" + t.getMessage();
        }
    }

    /**
     * Stoppt Scan & Writer.
     * Wird von deinem Python-Bridge-Wrapper aufgerufen.
     */
    public static void stop() {
        try {
            running = false;
            if (scanner != null && callback != null) {
                scanner.stopScan(callback);
            }
            Log.i(TAG, "stopped");
        } catch (Throwable t) {
            Log.e(TAG, "stop", t);
        }
    }

    // Dummy-Klasse, um den Verweis in onBatchScanResults zu kompilieren,
    // falls ScanSettings nicht importiert werden soll.
    // Alternativ kannst du oben "import android.bluetooth.le.ScanSettings;" einfügen
    // und diese innere Klasse entfernen.
    private static final class ScanSettings {
        static final int CALLBACK_TYPE_ALL_MATCHES = 1;
    }
}
