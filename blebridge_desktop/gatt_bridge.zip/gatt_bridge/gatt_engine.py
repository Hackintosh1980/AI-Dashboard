# gatt_engine.py – Desktop GATT → Pseudo-ADV (tb2) Bridge
# - Nutzt NUR GATT-Profile aus gatt_bridge/profiles
# - Schreibt IMMER nach: <PROJECT_ROOT>/data/ble_dump.json
# - Keine Decoder-Profile, keine zweiten data-Ordner

import asyncio
import json
import os
from datetime import datetime, timezone
from threading import Thread

from bleak import BleakScanner, BleakClient

# Ordner mit GATT-Profilen (tb2.json, tp35.json, …)
PROFILE_DIR = os.path.join(os.path.dirname(__file__), "profiles")

# Projekt-Root = …/session43/
PROJECT_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..")
)

# Zentrales BLE-Dump-File für den Decoder
OUTFILE = os.path.join(PROJECT_ROOT, "data", "ble_dump.json")


def extract_mac(addr: str) -> str:
    """
    MAC aus beliebigem CoreBluetooth-Identifier ziehen.
    Nimmt die letzten 12 HEX-Zeichen (= 6 Byte).
    """
    hex_only = "".join(c for c in addr if c in "0123456789ABCDEFabcdef").upper()
    return hex_only[-12:]


def build_tb2_pseudoadv(mac: str, data: bytes, counter: int) -> str:
    """
    Baut ein TB2-kompatibles Pseudo-ADV aus der GATT-Notify-Payload.

    Mapping (aus den Dumps abgeleitet):

      data[1:3]  -> T_i  (int. Temp)
      data[3:5]  -> H_i  (int. Hum)
      data[7:9]  -> T_e  (ext. Temp)
      data[9:11] -> H_e  (ext. Hum)

    Der Decoder erwartet:
      CID (0x0019, LE)
      + 6 Byte MAC (reversed)
      + 2 Byte Counter (LE)
      + 10 Byte Payload: T_i, H_i, T_e, H_e, packet
    """

    # 1) MAC extrahieren & reverse (wie bei dir schon):
    mac_clean = extract_mac(mac)              # z.B. "FABCEA8B7EC82594"
    mac_rev = bytes.fromhex(mac_clean)[::-1].hex().upper()

    # 2) 16-Bit Counter, little endian ins TB2-Format
    ctr = counter & 0xFFFF
    ctr_hex = f"{ctr:04X}"
    ctr_le = ctr_hex[2:] + ctr_hex[:2]       # "1234" -> "3412"

    # 3) Bytes aus GATT-Notify ziehen (Bounds-Check zur Sicherheit)
    if len(data) < 11:
        # Fallback: besser gar nichts als Müll
        return "19" + "00" + mac_rev + ctr_le + "0" * 20

    ti_lo, ti_hi = data[1], data[2]
    hi_lo, hi_hi = data[3], data[4]
    te_lo, te_hi = data[7], data[8]
    he_lo, he_hi = data[9], data[10]

    # 4) Packet-Counter für Decoder (8-Bit reicht)
    pkt = counter & 0xFF

    payload_bytes = bytes([
        ti_lo, ti_hi,
        hi_lo, hi_hi,
        te_lo, te_hi,
        he_lo, he_hi,
        pkt, 0x00,     # 2 Bytes "Rest" wie beim echten TB2 (D8 55 / etc.)
    ])

    payload_hex = payload_bytes.hex().upper()

    # 5) Finale RAW-String
    return "19" + "00" + mac_rev + ctr_le + payload_hex

class GattEngine:
    def __init__(self):
        self.running = False
        self.thread: Thread | None = None
        self.log_cb = None

    # ---------------------------------------------------------
    # Public API
    # ---------------------------------------------------------

    def start(self, device_name: str, profile_name: str, log_cb):
        """
        device_name: optional Override aus der UI (TextInput)
        profile_name: Name des GATT-Profils (z.B. "tb2", "tp35")
        log_cb: Callback für Log-Zeilen (UI.log)
        """
        self.log_cb = log_cb

        if self.running:
            if self.log_cb:
                self.log_cb("[ENGINE] Bereits aktiv.")
            return

        self.running = True
        self.thread = Thread(
            target=self._run_thread,
            args=(device_name.strip(), profile_name.strip()),
            daemon=True,
        )
        self.thread.start()

    def stop(self):
        self.running = False
        if self.log_cb:
            self.log_cb("[ENGINE] Stop-Signal gesetzt.")

    # ---------------------------------------------------------
    # Intern: Thread + Async-Loop
    # ---------------------------------------------------------

    def _run_thread(self, device_name: str, profile_name: str):
        try:
            asyncio.run(self._run_async(device_name, profile_name))
        except Exception as e:
            if self.log_cb:
                self.log_cb(f"[ENGINE] Fehler: {e!r}")

    async def _run_async(self, device_name: str, profile_name: str):
        # -------------------------------
        # Profil laden (rein GATT!)
        # -------------------------------
        prof_path = os.path.join(PROFILE_DIR, f"{profile_name}.json")
        if not os.path.exists(prof_path):
            if self.log_cb:
                self.log_cb(f"[ENGINE] Profil nicht gefunden: {prof_path}")
            return

        with open(prof_path, "r", encoding="utf-8") as f:
            profile = json.load(f)

        notify_uuid = profile["notify_uuid"]
        cmd_uuid = profile["command_uuid"]
        command = bytes.fromhex(profile["command"])
        convert = profile.get("convert_to_adv", "tb2")

        if self.log_cb:
            self.log_cb(f"[ENGINE] Profil geladen: {profile_name}")

        # -------------------------------
        # Device-Name bestimmen
        # -------------------------------
        search_name = self._select_device_name(device_name, profile_name, profile)

        if self.log_cb:
            self.log_cb(f"[ENGINE] Suche Gerät mit Name-Pattern: '{search_name}'")

        # Gerät suchen
        dev = None
        devs = await BleakScanner.discover()
        for d in devs:
            dname = d.name or ""
            if search_name in dname:
                dev = d
                break

        if not dev:
            if self.log_cb:
                self.log_cb("[ENGINE] Gerät nicht gefunden.")
            return

        if self.log_cb:
            self.log_cb(f"[ENGINE] Verbinde zu {dev.address} ({dev.name})")

        counter = 0

        # -------------------------------
        # GATT-Session
        # -------------------------------
        async with BleakClient(dev.address, timeout=15.0) as client:
            if self.log_cb:
                self.log_cb("[ENGINE] Verbunden ✔")

            # zentrales Dump-File vorbereiten
            os.makedirs(os.path.dirname(OUTFILE), exist_ok=True)
            with open(OUTFILE, "w", encoding="utf-8") as f:
                json.dump([], f)

            async def handle_notify(_, data: bytearray):
                nonlocal counter
                counter += 1

                if convert == "tb2":
                    raw = build_tb2_pseudoadv(dev.address, data, counter)
                else:
                    raw = data.hex().upper()

                entry = {
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "name": dev.name,
                    "address": dev.address,
                    "rssi": 0,
                    "raw": raw,
                    "note": "gatt",
                }

                # Immer EIN zentrales Array mit genau einem Eintrag
                with open(OUTFILE, "w", encoding="utf-8") as f:
                    json.dump([entry], f, indent=2, ensure_ascii=False)

                if self.log_cb:
                    self.log_cb(f"[RAW] {raw}")

                # Sofort nächste Statusabfrage
                await client.write_gatt_char(cmd_uuid, command)

            # Notifications aktivieren + erster Kick
            await client.start_notify(notify_uuid, handle_notify)
            await client.write_gatt_char(cmd_uuid, command)

            if self.log_cb:
                self.log_cb("[ENGINE] Lausche auf Notifications…")

            while self.running:
                await asyncio.sleep(0.2)

            if self.log_cb:
                self.log_cb("[ENGINE] Stoppe Bridge…")

            await client.stop_notify(notify_uuid)

    # ---------------------------------------------------------
    # Helper
    # ---------------------------------------------------------

    def _select_device_name(self, ui_name: str, profile_name: str, profile: dict) -> str:
        """
        Priorität:
        1. UI-Override (TextInput)
        2. device_name im Profil
        3. bekannte Fallbacks (tb2 / tp35)
        4. Profilname
        """
        if ui_name:
            return ui_name

        prof_dev = profile.get("device_name")
        if prof_dev:
            return prof_dev

        pn = profile_name.lower()
        if pn.startswith("tb2"):
            return "ThermoBeacon2"
        if pn.startswith("tp35"):
            return "TP351"  # matched "TP351S (987A)" als Substring

        return profile.get("name", profile_name)
