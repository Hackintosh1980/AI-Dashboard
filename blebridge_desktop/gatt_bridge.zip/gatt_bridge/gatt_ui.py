# gatt_ui.py – Kivy-UI für Desktop-GATT-Bridge
# - NUR GATT-Profile aus gatt_bridge/profiles
# - Device-Feld ist nur Override, Profil steuert Standard
# - Start/Stop nutzt GattEngine.start/stop

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.clock import Clock

import os
from gatt_engine import GattEngine, PROFILE_DIR


def load_profiles():
    if not os.path.isdir(PROFILE_DIR):
        return ()
    return tuple(
        sorted(
            fn[:-5]  # .json weg
            for fn in os.listdir(PROFILE_DIR)
            if fn.endswith(".json")
        )
    )


class GattUI(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", **kwargs)

        self.engine = GattEngine()

        # Device Name (optional Override, bewusst LEER)
        self.dev_input = TextInput(
            text="",
            hint_text="optional: Gerätename override (z.B. ThermoBeacon2)",
            size_hint=(1, 0.1),
            multiline=False,
        )
        self.add_widget(self.dev_input)

        # Profil-Auswahl (reine GATT-Profile)
        self.prof_spinner = Spinner(
            text="Profil wählen",
            values=load_profiles(),
            size_hint=(1, 0.1),
        )
        self.add_widget(self.prof_spinner)

        # Start / Stop
        btns = BoxLayout(size_hint=(1, 0.15))

        self.start_btn = Button(text="START")
        self.start_btn.bind(on_press=self.on_start)
        btns.add_widget(self.start_btn)

        self.stop_btn = Button(text="STOP")
        self.stop_btn.bind(on_press=self.on_stop)
        btns.add_widget(self.stop_btn)

        self.add_widget(btns)

        # Log-Output
        self.log_box = TextInput(
            readonly=True,
            size_hint=(1, 0.65),
        )
        self.add_widget(self.log_box)

        # Initial-Hinweis
        self.log("[UI] Bitte Profil wählen, Device optional überschreiben.")

    # ---------------------------------------

    def log(self, msg: str):
        Clock.schedule_once(lambda dt: self._append(msg))

    def _append(self, msg: str):
        self.log_box.text += msg + "\n"
        self.log_box.cursor = (0, len(self.log_box.text))

    # ---------------------------------------

    def on_start(self, *_):
        dev = self.dev_input.text.strip()
        prof = self.prof_spinner.text.strip()

        if not prof or prof == "Profil wählen":
            self.log("[UI] Kein Profil gewählt.")
            return

        self.log(f"[UI] Starte Engine mit Profil '{prof}'"
                 + (f" und Device-Override '{dev}'" if dev else ""))
        self.engine.start(dev, prof, self.log)

    def on_stop(self, *_):
        self.log("[UI] Stop angefordert.")
        self.engine.stop()


class GattUIApp(App):
    def build(self):
        return GattUI()


if __name__ == "__main__":
    GattUIApp().run()
